from typing import Any, Callable, TypeVar, overload


_T = TypeVar('_T')


class Substitution:
    @overload
    def __init__(self, *args: str): ...
    @overload
    def __init__(self, **kwargs: str): ...
    def __call__(self, func: _T) -> _T: ...
    def update(self, *args, **kwargs): ...  # type: ignore[no-untyped-def]


class _ArtistKwdocLoader(dict[str, str]):
    def __missing__(self, key: str) -> str: ...


class _ArtistPropertiesSubstitution(Substitution):
    def __init__(self) -> None: ...
    def __call__(self, obj: _T) -> _T: ...


def copy(source: Any) -> Callable[[_T], _T]: ...


dedent_interpd: _ArtistPropertiesSubstitution
interpd: _ArtistPropertiesSubstitution
