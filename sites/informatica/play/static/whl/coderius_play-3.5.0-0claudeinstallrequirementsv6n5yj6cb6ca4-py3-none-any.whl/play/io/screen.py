"""This module provides a wrapper around the Pygame display module to create a screen object"""

import pygame
import pymunk as _pymunk

from play.callback import run_callback, CallbackType, callback_manager
from play.callback.collision_callbacks import WallSide
from play.globals import globals_list
from play.physics import physics_space
from play.utils.async_helpers import make_async

_DEFAULT_CAPTION = "coderius-play"


class Screen:
    def update_display(self, extra_flags=0):
        """Update the display with the current width and height."""
        flags = pygame.DOUBLEBUF | extra_flags
        if self._resizable:
            flags |= pygame.RESIZABLE
        globals_list.display = pygame.display.set_mode(
            (self._width, self._height),
            flags,
        )

    def __init__(self, width=globals_list.width, height=globals_list.height):
        self._width = width
        self._height = height

        self._resizable = False
        self._fullscreen = False
        self._caption = _DEFAULT_CAPTION

        self.update_display()
        pygame.display.set_caption(self._caption)

    @property
    def caption(self):
        """Get the caption of the screen.
        :return: The caption of the screen."""
        return self._caption

    @caption.setter
    def caption(self, _caption):
        """Set the caption of the screen.
        :param _caption: The new caption of the screen."""
        self._caption = _caption
        pygame.display.set_caption(self._caption)

    @property
    def resizable(self):
        """Get whether the screen is resizable.
        :return: Whether the screen is resizable."""
        return self._resizable

    @resizable.setter
    def resizable(self, _resizable):
        """Set whether the screen is resizable.
        :param _resizable: Whether the screen is resizable."""
        self._resizable = _resizable
        self.update_display()

    @property
    def width(self):
        """Get the width of the screen.
        :return: The width of the screen."""
        return self._width

    @width.setter
    def width(self, _width):
        """Set the width of the screen.
        :param _width: The new width of the screen."""
        self._set_size(_width, self._height)

    @property
    def height(self):
        """Get the height of the screen.
        :return: The height of the screen."""
        return self._height

    @height.setter
    def height(self, _height):
        """Set the height of the screen.
        :param _height: The new height of the screen."""
        self._set_size(self._width, _height)

    def _reset(self):
        """Go back to the size, window flags and caption of a new screen, with fresh walls."""
        self._width, self._height = globals_list.width, globals_list.height
        self._resizable = False
        self.caption = _DEFAULT_CAPTION
        self.update_display()
        _create_walls_on_a_new_body()

    def _set_size(self, width, height):
        """Resize the window and move the walls to its new edges."""
        self._width = width
        self._height = height
        self.update_display()
        rebuild_walls()

    @property
    def top(self):
        """Get the top side of the screen.
        :return: The top side of the screen."""
        return self.height / 2

    @property
    def bottom(self):
        """Get the bottom side of the screen.
        :return: The bottom side of the screen."""
        return self.height / -2

    @property
    def left(self):
        """Get the left side of the screen.
        :return: The left side of the screen."""
        return self.width / -2

    @property
    def right(self):
        """Get the right side of the screen.
        :return: The right side of the screen."""
        return self.width / 2

    @property
    def size(self):
        """Get the size of the screen.
        :return: The size of the screen."""
        return self.width, self.height

    def when_resized(self, func):
        """Run a function when the screen is resized.
        :param func: The function to run."""
        async_callback = make_async(func)

        async def wrapper():
            run_callback(
                async_callback,
                [],
                [],
            )

        callback_manager.add_callback(
            CallbackType.WHEN_RESIZED,
            wrapper,
        )
        return func

    def resize(self, new_width, new_height):
        """Resize the screen to new dimensions.

        :param new_width: The new width of the screen
        :param new_height: The new height of the screen
        :raises RuntimeError: If sprites have already been created
        """
        # Check if any sprites exist
        if len(globals_list.sprites_group) > 0:
            sprite_count = len(globals_list.sprites_group)
            sprite_word = "sprite" if sprite_count == 1 else "sprites"
            raise RuntimeError(
                f"Screen must be resized before creating sprites.\n\n"
                f"Problem: You called play.screen.resize() after creating {sprite_count} {sprite_word}.\n"
                f"Solution: Move play.screen.resize() to the beginning of your script:\n\n"
                f"    import play\n"
                f"    play.screen.resize({new_width}, {new_height})  # ← Move this here\n"
                f"    cirkel = play.new_circle()     # ← Before creating sprites\n"
            )

        self._set_size(new_width, new_height)


screen = Screen()

_walls_body = _pymunk.Body(body_type=_pymunk.Body.STATIC)
_WALL_RADIUS = 10


def create_wall(a, b, wall_side):
    """Create a wall segment in the physics space.
    :param a: The start point of the wall segment.
    :param b: The end point of the wall segment.
    :param wall_side: The side of the screen this wall represents (WallSide enum)."""
    if _walls_body.space is None:
        physics_space.add(_walls_body)
    segment = _pymunk.Segment(_walls_body, a, b, _WALL_RADIUS)
    segment.elasticity = 1.0
    segment.friction = 0.0
    segment.wall_side = wall_side
    segment._play_collision_type_set = False
    segment.collision_id = None
    physics_space.add(segment)
    return segment


def _wall_edges():
    """The four walls as ``(a, b, wall_side)``, in wall-index order, their inner face on the screen edge."""
    left, right = screen.left - _WALL_RADIUS, screen.right + _WALL_RADIUS
    top, bottom = screen.top + _WALL_RADIUS, screen.bottom - _WALL_RADIUS
    return [
        ((left, top), (right, top), WallSide.TOP),
        ((left, bottom), (right, bottom), WallSide.BOTTOM),
        ((left, bottom), (left, top), WallSide.LEFT),
        ((right, bottom), (right, top), WallSide.RIGHT),
    ]


def create_walls():
    """Create walls around the screen."""
    for a, b, wall_side in _wall_edges():
        globals_list.walls.append(create_wall(a, b, wall_side))


def _create_walls_on_a_new_body():
    """Create the walls on a new static body, so the old body lets go of its walls."""
    global _walls_body
    _walls_body = _pymunk.Body(body_type=_pymunk.Body.STATIC)
    create_walls()


def remove_walls():
    """Remove the walls from the physics space."""
    for wall in globals_list.walls:
        physics_space.remove(wall)
    globals_list.walls.clear()


def rebuild_walls():
    """Move the walls to the current screen edges.

    The segments are moved in place, so the collision_type that wall
    callbacks are keyed on stays with them. A side that was taken away with
    remove_wall() comes back, as it always has.
    """
    existing = {}
    for wall in globals_list.walls:
        side = getattr(wall, "wall_side", None)
        if side is None or side in existing:
            # Not one of the four: drop it from the space, as the old
            # remove-everything-and-recreate did.
            physics_space.remove(wall)
        else:
            existing[side] = wall
    globals_list.walls.clear()
    for a, b, wall_side in _wall_edges():
        wall = existing.get(wall_side)
        if wall is None:
            wall = create_wall(a, b, wall_side)
        else:
            # pymunk calls this unsafe because a moved shape does not push
            # away what it now overlaps. Walls are static and only move on a
            # resize, which is the same teleport the old rebuild was.
            wall.unsafe_set_endpoints(a, b)
            physics_space.reindex_shape(wall)
        globals_list.walls.append(wall)


def remove_wall(index):
    """Remove a wall from the physics space.
    :param index: The index of the wall to remove. 0: top, 1: bottom, 2: left, 3: right.
    """
    side = _wall_edges()[index][2]
    for wall in [wall for wall in globals_list.walls if wall.wall_side == side]:
        physics_space.remove(wall)
        globals_list.walls.remove(wall)


create_walls()


def convert_pos(x, y):
    """
    Convert from the Play coordinate system to the Pygame coordinate system.
    :param x: The x-coordinate in the Play coordinate system.
    :param y: The y-coordinate in the Play coordinate system.
    """
    x1 = screen.width / 2 + x
    y1 = screen.height / 2 - y
    return x1, y1


def pos_convert(x, y):
    """
    Convert from the Pygame coordinate system to the Play coordinate system.
    :param x: The x-coordinate in the Pygame coordinate system.
    :param y: The y-coordinate in the Pygame coordinate system.
    """
    x1 = x - screen.width / 2
    y1 = screen.height / 2 - y
    return x1, y1
