"""This module contains the Mouse class and the mouse object."""

import math as _math

from play.callback import callback_manager, CallbackType
from play.utils.async_helpers import make_async
from play.objects.sprite import point_touching_sprite
from play.callback.callback_helpers import run_async_callback


class Mouse:
    def __init__(self):
        self.x = 0
        self.y = 0
        self._is_clicked = False

    @property
    def is_clicked(self):
        """Return whether the mouse is clicked.
        :return: True if the mouse is clicked, False otherwise."""
        return self._is_clicked

    def is_touching(self, other):
        """Check if the mouse is touching a sprite.
        :param other: The sprite to check.
        :return: True if the mouse is touching the sprite, False otherwise."""
        return point_touching_sprite((self.x, self.y), other)

    # @decorator
    def when_clicked(self, func):
        """Run a function when the mouse is clicked.
        :param func: The function to run."""
        async_callback = make_async(func)

        async def wrapper():
            await run_async_callback(
                async_callback,
                [],
                [],
            )

        callback_manager.add_callback(
            CallbackType.WHEN_CLICKED,
            wrapper,
        )
        return wrapper

    # @decorator
    def when_click_released(self, func):
        """Run a function when the mouse click is released.
        :param func: The function to run."""
        async_callback = make_async(func)

        async def wrapper():
            await run_async_callback(
                async_callback,
                [],
                [],
            )

        callback_manager.add_callback(
            CallbackType.WHEN_CLICK_RELEASED,
            wrapper,
        )
        return wrapper

    # @decorator
    def while_pressed(self, func):
        """Run a function every frame while the mouse button is held down.
        :param func: The function to run."""
        async_callback = make_async(func)

        async def wrapper():
            wrapper.is_running = True
            await run_async_callback(
                async_callback,
                [],
                [],
            )
            wrapper.is_running = False

        wrapper.is_running = False
        callback_manager.add_callback(
            CallbackType.WHILE_MOUSE_PRESSED,
            wrapper,
        )
        return wrapper

    def distance_to(self, x: int | float, y: int | float):
        """Get the distance from the mouse to a point.
        :param x: The x-coordinate of the point.
        :param y: The y-coordinate of the point.
        :return: The distance from the mouse to the point."""
        assert x is not None and y is not None, "x and y must not be None"

        return _math.dist((self.x, self.y), (x, y))


mouse = Mouse()
