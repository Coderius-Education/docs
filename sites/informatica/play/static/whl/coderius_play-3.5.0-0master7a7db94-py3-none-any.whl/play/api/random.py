"""Generate random numbers, colors, and positions."""

import random as _random

import pygame

from play.io.screen import screen


def random_number(lowest=0, highest=100):
    """Return a random number between `lowest` and `highest`.
    :param lowest: The lowest number that can be returned.
    :param highest: The highest number that can be returned.
    :return: A random number between `lowest` and `highest`.
    """
    if lowest > highest:
        raise ValueError(
            f"""random_number() needs the lowest number first, but got lowest={lowest} and highest={highest}.
Try play.random_number({highest}, {lowest}) instead."""
        )
    if isinstance(lowest, int) and isinstance(highest, int):
        return _random.randint(lowest, highest)
    # if user supplied any floats, return decimals
    return round(_random.uniform(lowest, highest), 2)


def random_color():
    """Return a random color.
    :return: A random color.
    """
    return random_number(0, 255), random_number(0, 255), random_number(0, 255)


def random_position(x_min=None, x_max=None, y_min=None, y_max=None):
    """
    Returns a random position on the screen. A position has an `x` and `y` e.g.:
        position = play.random_position()
        sprite.x = position.x
        sprite.y = position.y

    Or equivalently:
        sprite.x, sprite.y = play.random_position()
    """
    if x_min is None:
        x_min = screen.left
    if x_max is None:
        x_max = screen.right
    if y_min is None:
        y_min = screen.bottom
    if y_max is None:
        y_max = screen.top
    return pygame.math.Vector2(
        random_number(x_min, x_max),
        random_number(y_min, y_max),
    )
