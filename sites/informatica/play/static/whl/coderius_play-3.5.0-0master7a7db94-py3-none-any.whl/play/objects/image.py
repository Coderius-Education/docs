"""This module contains the Image class, which is a subclass of the Sprite class."""

import os
import pygame

from play.objects.sprite import Sprite
from play.utils import scale_to_percent as _scale_to_percent


class Image(Sprite):
    _scaled_by_size = True

    def __init__(
        self, image, x=0, y=0, angle=0, size=100, transparency=100, anchor=None, layer=0
    ):
        if isinstance(image, str):
            if not os.path.isfile(image):
                raise FileNotFoundError(f"Image file '{image}' not found.")
            self._image_filename = image
            # Keep the original, loaded image safe from modifications.
            self._source_image = pygame.image.load(image)
        else:
            self._image_filename = None
            self._source_image = image

        self._angle = angle
        self._size = size
        self._transparency = transparency
        self.rect = self._source_image.get_rect()

        super().__init__(image=self._source_image, x=x, y=y, anchor=anchor, layer=layer)
        self.update()

    def _render(self):
        """Scale, rotate, and alpha-blend the source image."""
        # Always a scaled copy, so set_alpha never touches the source surface.
        self._place_image(_scale_to_percent(self._source_image, self._size))

    def _unscaled_size(self):
        """Return the size of the source image."""
        return self._source_image.get_size()

    def clone(self):
        """Create a copy of the image.
        :return: A copy of the image."""
        return self.__class__(
            image=self._image_filename or self._source_image,
            **self._common_properties(),
        )

    # The custom image property is removed to use the parent Sprite's property.
    # This ensures that the image managed by the Pygame sprite group is the
    # one generated in the update method.

    @property
    def image_filename(self):
        """Return the image filename."""
        return self._image_filename

    @image_filename.setter
    def image_filename(self, image: str):
        """Set the image from a file."""
        if not os.path.isfile(image):
            raise FileNotFoundError(f"Image file '{image}' not found.")
        self._image_filename = image
        self._source_image = pygame.image.load(image)
        self._should_recompute = True
        self.physics._resize_shape()
        self.update()
