"""This module contains the base sprite class for all objects in the game."""

import math as _math
import warnings as _warnings

import pygame
import pymunk as _pymunk

from play.api.auto_start import _schedule_auto_start
from play.callback import callback_manager, CallbackType
from play.callback.collision_callbacks import collision_registry
from play.globals import globals_list
from play.io.screen import screen, convert_pos
from play.physics import physics_space, Physics as _Physics
from play.utils import is_called_from_pygame, scale_to_percent as _scale_to_percent
from play.objects.components import EventComponent


def point_touching_sprite(point, sprite):
    """Check if a point is touching a sprite using pymunk collision detection.
    :param point: The point (x, y tuple) to check if it's touching the sprite.
    :param sprite: The sprite to check if it's touching the point.
    :return: Whether the point is touching the sprite."""
    if not sprite._can_touch():
        return False
    point_info = sprite.physics._pymunk_shape.point_query(point)
    return point_info.distance <= 0


_should_ignore_update = frozenset(
    {
        "_should_recompute",
        "rect",
        "_image",
    }
)


class Sprite(pygame.sprite.Sprite):  # pylint: disable=too-many-public-methods
    # Interactive widgets set this True: a click goes to the top-most widget
    # only, while plain sprites under the cursor all receive it.
    _is_widget = False

    # UI sets this True: the body every sprite gets automatically is then a
    # sensor, used for hit-testing (hover, clicks) without being something a
    # ball can bounce off. start_physics() called by the student still gives
    # a solid body, as it does for every sprite.
    _sensor_by_default = False

    # Read directly; subclasses may set these before super().__init__().
    _image = None
    rect = None
    physics = None
    _size = 100
    _color = None
    _is_disabled = False
    _angle = 0
    _transparency = 100
    _is_hidden = False
    events = None
    _x = None
    _y = None

    @staticmethod
    def _init_anchor_attrs(instance, x, y, anchor, layer):
        """Write anchor/layer attrs via object.__setattr__ to avoid triggering
        _should_recompute.  Called from both Sprite.__init__ and Text.__init__
        (which must initialise these before its early self.update() call)."""
        object.__setattr__(instance, "_layer", layer)
        object.__setattr__(instance, "_anchor", anchor)
        object.__setattr__(instance, "_anchor_ox", x)
        object.__setattr__(instance, "_anchor_oy", y)

    def __init__(self, image=None, x=0, y=0, anchor=None, layer=0):
        # Subclasses set their own field values BEFORE calling super().__init__() so
        # that start_physics() can use the correct dimensions; the class
        # defaults above cover Sprite instantiated directly.

        # Anchor/layer attrs bypass __setattr__ to avoid triggering _should_recompute.
        # Text calls this same helper before its early update() so the values are
        # already set; we overwrite unconditionally — the values are identical.
        Sprite._init_anchor_attrs(self, x, y, anchor, layer)

        # _x/_y: use anchor-aware defaults unless the subclass already set them
        # (Text sets these before calling super() because it calls update() first).
        if self._x is None:
            self._x = 0 if anchor else x
        if self._y is None:
            self._y = 0 if anchor else y

        self.events = EventComponent(self)

        if self._image is None:
            self._image = image
        self._should_recompute = True

        if self.rect is None:
            self.rect = pygame.Rect(0, 0, 0, 0)

        # Pygame sprite initializes internal variables but clobbers rect and image, so we back it up
        _backup_rect = self.rect
        _backup_image = self._image

        super().__init__()
        globals_list.sprites_group.add(self, layer=self._layer)

        self.rect = _backup_rect
        if _backup_image is not None:
            self._image = _backup_image

        self.start_physics(
            stable=True, obeys_gravity=False, sensor=self._sensor_by_default
        )

        _schedule_auto_start()

    def __setattr__(self, name, value):
        # ignore if it's in the ignored list or if the variable doesn't change
        if name not in _should_ignore_update and getattr(self, name, value) != value:
            self._should_recompute = True
            if self.events is not None:
                for sprite in self.events._dependent_sprites:
                    sprite._should_recompute = True
        super().__setattr__(name, value)

    @property
    def layer(self):
        """The render layer this sprite belongs to (higher = drawn on top)."""
        return self._layer

    @layer.setter
    def layer(self, value):
        """Move the sprite to a different render layer."""
        object.__setattr__(self, "_layer", value)
        # A removed sprite is no longer in the group; LayeredUpdates.change_layer
        # raises for non-members. Keep _layer so a later re-add uses it.
        if globals_list.sprites_group.has(self):
            globals_list.sprites_group.change_layer(self, value)

    def _anchor_size(self):
        """Return the ``(width, height)`` that anchoring places on the screen."""
        return self.rect.size

    def _apply_anchor(self):
        """Recompute x/y from the anchor + offsets and current screen dimensions.

        For edge anchors ("top-left", "bottom-right", etc.) ox/oy are pixel
        distances inward from the anchored screen border — the sprite's relevant
        EDGE lands exactly ox/oy pixels from that border.

        For "center", ox/oy are play-coordinate offsets from the screen centre
        (same as a plain x/y without an anchor), not pixel distances from any edge.

        Half-dimensions come from the previous frame's rect, so edge placement
        is accurate from frame 2 onward; frame 1 uses w2=h2=0.  Text pre-renders
        in __init__ so it is correct from game-loop frame 1.
        """
        ox, oy = self._anchor_ox, self._anchor_oy
        a = self._anchor
        width, height = self._anchor_size()
        w2 = width / 2
        h2 = height / 2

        parts = a.split("-")
        if len(parts) > 2:
            _warnings.warn(
                f"Unknown anchor value '{a}'. "
                "Valid values: 'top-left', 'top-center', 'top-right', "
                "'center-left', 'center', 'center-right', "
                "'bottom-left', 'bottom-center', 'bottom-right'.",
                UserWarning,
                stacklevel=2,
            )
            return
        y_key = parts[0]
        x_key = parts[1] if len(parts) > 1 else "center"
        nx = {
            "left": screen.left + ox + w2,
            "center": ox,
            "right": screen.right - ox - w2,
        }.get(x_key)
        ny = {
            "top": screen.top - oy - h2,
            "center": oy,
            "bottom": screen.bottom + oy + h2,
        }.get(y_key)

        if nx is None or ny is None:
            _warnings.warn(
                f"Unknown anchor value '{a}'. "
                "Valid values: 'top-left', 'top-center', 'top-right', "
                "'center-left', 'center', 'center-right', "
                "'bottom-left', 'bottom-center', 'bottom-right'.",
                UserWarning,
                stacklevel=2,
            )
            return

        if self.physics is not None:
            if nx != self._x or ny != self._y:
                self.x, self.y = nx, ny
                # Dynamic bodies accumulate velocity against the anchor each frame;
                # reset it so collision responses stay physically meaningful.
                if self.physics._pymunk_body.body_type == _pymunk.Body.DYNAMIC:
                    self.physics._pymunk_body.velocity = (0, 0)
        else:
            self._x, self._y = nx, ny
            self._should_recompute = True

    def is_touching_wall(self) -> bool:
        """Check if the sprite is touching the edge of the screen.
        :return: Whether the sprite is touching the edge of the screen."""
        return len(self.get_touching_walls()) > 0

    def get_touching_walls(self) -> list:
        """Get a list of WallSide values for walls the sprite is currently touching.
        :return: A list of WallSide enum values."""
        if not self._can_touch():
            return []
        touching = []
        for wall in globals_list.walls:
            try:
                contact_set = self.physics._pymunk_shape.shapes_collide(wall)
                if contact_set and len(contact_set.points) > 0:
                    touching.append(wall.wall_side)
            except (AssertionError, AttributeError):
                continue
        return touching

    def update(self):
        """Orchestrate per-frame rendering: render, apply anchor, re-render if moved."""
        # A dynamic body that obeys gravity is owned by the physics simulation;
        # re-applying the anchor would snap it back and zero its velocity every
        # frame, so the sprite could never fall or be pushed.
        physics = self.physics
        anchored = self._anchor and not (
            physics is not None
            and physics.obeys_gravity
            and physics._pymunk_body.body_type == _pymunk.Body.DYNAMIC
        )
        # Render first so rect holds *this* frame's size: _apply_anchor reads it,
        # and a stale one mispositions anything whose content changes.
        self._recompute_image()
        if anchored:
            self._apply_anchor()
            self._recompute_image()  # no-op unless the anchor moved the sprite

    def _recompute_image(self):
        """Redraw into self.image if the sprite is marked dirty."""
        if not self._should_recompute:
            return
        if self._is_hidden:
            self._image = pygame.Surface((0, 0), pygame.SRCALPHA)
        else:
            self._render()
            if not self._scaled_by_size and self.physics is not None:
                self.physics._resize_shape()
        self._should_recompute = False

    def _render(self):
        """Override in subclasses to draw the shape-specific image onto self.image."""

    @property
    def is_clicked(self):
        """Whether the sprite was clicked in this frame; play.mouse.is_clicked stays True while held.
        :return: Whether the sprite was clicked in this frame."""
        return self.events.is_clicked

    @property
    def x(self):
        """Get the x-coordinate of the sprite.
        :return: The x-coordinate of the sprite."""
        return self._x

    @x.setter
    def x(self, _x):
        """Set the x-coordinate of the sprite. A physics sprite keeps its speed.
        :param _x: The x-coordinate of the sprite."""
        # Requires self.physics to be initialized; only safe after Sprite.__init__() completes.
        self._x = _x
        self._move_body()

    @property
    def y(self):
        """Get the y-coordinate of the sprite.
        :return: The y-coordinate of the sprite."""
        return self._y

    @y.setter
    def y(self, _y):
        """Set the y-coordinate of the sprite. A physics sprite keeps its speed.
        :param _y: The y-coordinate of the sprite."""
        # Requires self.physics to be initialized; only safe after Sprite.__init__() completes.
        self._y = _y
        self._move_body()

    def _move_body(self):
        """Move the pymunk body and its shape to ``(x, y)`` right away."""
        self.physics._pymunk_body.position = self._x, self._y
        self._reindex_body()

    def _reindex_body(self):
        """Let pymunk see a moved or turned body before the next physics step."""
        self.physics._pymunk_shape.cache_bb()
        if self.physics._pymunk_body.body_type == _pymunk.Body.STATIC:
            physics_space.reindex_static()

    @property
    def transparency(self):
        """Get the transparency of the sprite.
        :return: The transparency of the sprite."""
        return self._transparency

    @transparency.setter
    def transparency(self, alpha):
        """Set the transparency of the sprite.
        :param alpha: The transparency of the sprite."""
        if not isinstance(alpha, float) and not isinstance(alpha, int):
            raise ValueError(
                f"""Looks like you're trying to set {self}'s transparency to '{alpha}', which isn't a number.
Try looking in your code for where you're setting transparency for {self} and change it a number.
"""
            )
        if alpha > 100 or alpha < 0:
            _warnings.warn(
                f"""The transparency setting for {self} is being set to {alpha} and it should be between 0 and 100.
You might want to look in your code where you're setting transparency and make sure it's between 0 and 100.  """,
                UserWarning,
            )

        self._transparency = pygame.math.clamp(alpha, 0, 100)

    @property
    def image(self):
        """Get the image of the sprite.
        :return: The image of the sprite."""
        return self._image

    @image.setter
    def image(self, image_filename):
        """Set the image of the sprite.
        :param image_filename: The filename of the image to set."""
        self._image = image_filename

    @property
    def angle(self):
        """Get the angle of the sprite.
        :return: The angle of the sprite."""
        return self._angle

    @angle.setter
    def angle(self, _angle):
        """Set the angle of the sprite.
        :param _angle: The angle of the sprite."""
        # Requires self.physics to be initialized; only safe after Sprite.__init__() completes.
        self._angle = _angle
        self.physics._pymunk_body.angle = _math.radians(_angle)
        self._reindex_body()

    @property
    def size(self):
        """Get the size of the sprite.
        :return: The size of the sprite."""
        return self._size

    @size.setter
    def size(self, percent):
        """Set the size of the sprite.
        :param percent: The size of the sprite as a percentage."""
        # Requires self.physics to be initialized; only safe after Sprite.__init__() completes.
        self._should_recompute = True
        self._size = percent
        self.physics._resize_shape()

    def hide(self):
        """Hide the sprite."""
        if self._is_hidden:
            return
        self._is_hidden = True
        if self.alive():
            self.physics.pause()

    def show(self):
        """Show the sprite."""
        if not self._is_hidden:
            return
        self._is_hidden = False
        if self.alive():
            self.physics.unpause()

    @property
    def is_hidden(self):
        """Get whether the sprite is hidden.
        :return: Whether the sprite is hidden."""
        return self._is_hidden

    @is_hidden.setter
    def is_hidden(self, hide):
        """Set whether the sprite is hidden.
        :param hide: Whether the sprite is hidden."""
        if hide:
            self.hide()
        else:
            self.show()

    @property
    def is_shown(self):
        """Get whether the sprite is shown.
        :return: Whether the sprite is shown."""
        return not self._is_hidden

    @is_shown.setter
    def is_shown(self, show):
        """Set whether the sprite is shown.
        :param show: Whether the sprite is shown."""
        if show:
            self.show()
        else:
            self.hide()

    def is_touching(self, sprite_or_point):
        """Check if the sprite is touching another sprite or a point.
        :param sprite_or_point: The sprite or point to check if it's touching.
        :return: Whether the sprite is touching the other sprite or point."""
        if isinstance(sprite_or_point, Sprite):
            if not (self._can_touch() and sprite_or_point._can_touch()):
                return False
            try:
                contact_set = self.physics._pymunk_shape.shapes_collide(
                    sprite_or_point.physics._pymunk_shape
                )
                return len(contact_set.points) > 0
            except (AssertionError, AttributeError):
                # Fallback: shapes might not be in a valid state for collision check
                return False
        return point_touching_sprite(sprite_or_point, self)

    def _can_touch(self):
        """Whether the sprite takes part in touching: shown, not removed, not empty."""
        return not self._is_hidden and self.alive() and self.physics._has_area

    def distance_to(self, x, y=None):
        """Calculate the distance to a point or sprite.
        :param x: The x-coordinate of the point, or a sprite object.
        :param y: The y-coordinate of the point (required when x is a number).
        :return: The distance to the point or sprite."""
        assert x is not None

        try:
            # x can either be a number or a sprite. If it's a sprite:
            x1 = x.x
            y1 = x.y
        except AttributeError as exc:
            if y is None:
                raise ValueError(
                    "distance_to() requires a y argument when x is a number, "
                    "or pass a sprite object as x."
                ) from exc
            x1 = x
            y1 = y

        return _math.dist((self.x, self.y), (x1, y1))

    def info(self):
        """Print a short summary of this sprite."""
        sprite_type = self.__class__.__name__
        color = self._color if self._color is not None else "unknown"
        size_info = self._info_size()
        hidden = " (hidden)" if self._is_hidden else ""

        print(f"Hi, I'm a {sprite_type}!")
        print(f"  Color: {color}")
        print(f"  Position: x={self.x}, y={self.y}")
        if size_info:
            print(f"  Size: {size_info}")
        print(f"  Angle: {self.angle}°{hidden}")

    def _info_size(self):
        """The size part of info(); Circle reports its radius instead."""
        return f"width={self.width}, height={self.height}"

    def _tick(self):
        """Per-frame hook, called before the hidden check; Video advances here."""

    def _handle_frame_events(self):
        """Per-frame input hook. Return True to claim this frame's click."""
        return False

    def physics_info(self):
        """Print a summary of this sprite's physics properties."""
        body_type = self.physics._pymunk_body.body_type

        # Dutch names for body types
        type_names = {
            _pymunk.Body.DYNAMIC: ("DYNAMIC", "VRIJ"),
            _pymunk.Body.KINEMATIC: ("KINEMATIC", "GESTUURD"),
            _pymunk.Body.STATIC: ("STATIC", "VAST"),
        }
        eng_name, nl_name = type_names.get(body_type, ("UNKNOWN", "ONBEKEND"))

        print(f"Physics: {eng_name} ({nl_name})")
        print(
            f"can_move={self.physics.can_move},stable={self.physics.stable},obeys_gravity={self.physics.obeys_gravity}"
        )
        print(f"  Speed: x={self.physics.x_speed}, y={self.physics.y_speed}")
        print(f"  Mass: {self.physics.mass}, Bounciness: {self.physics.bounciness}")

        # Collision info
        print("\nCollision behavior:")
        if body_type == _pymunk.Body.DYNAMIC:
            print("  ✓ Collides with DYNAMIC (VRIJ)")
            print("  ✓ Collides with KINEMATIC (GESTUURD)")
            print("  ✓ Collides with STATIC (VAST)")
        elif body_type == _pymunk.Body.KINEMATIC:
            print("  ✓ Collides with DYNAMIC (VRIJ)")
            print("  ✗ Passes through KINEMATIC (GESTUURD)")
            print("  ✗ Passes through STATIC (VAST)")
        else:  # STATIC
            print("  ✓ Collides with DYNAMIC (VRIJ)")
            print("  ✗ Passes through KINEMATIC (GESTUURD)")
            print("  ✗ Passes through STATIC (VAST)")

    def remove(self):
        """Remove the sprite from the screen."""
        if not self.alive():
            return
        saved = self._save_and_clear_callbacks()
        # Wall callback types don't register in _dependent_sprites, so only
        # WHEN_TOUCHING / WHEN_STOPPED_TOUCHING need cleanup here.
        for cb_type in [CallbackType.WHEN_TOUCHING, CallbackType.WHEN_STOPPED_TOUCHING]:
            for _, target in saved[cb_type]:
                target.events._dependent_sprites.discard(self)
        collision_registry.forget(self.physics._pymunk_shape)
        for callback_type in CallbackType:
            callback_manager.remove_callbacks(callback_type, id(self))
        self.physics._remove()
        globals_list.sprites_group.remove(self)

    def add(self, *groups):
        """Add the sprite to groups (pygame internal method).
        Warning: This is a pygame internal method. Use at your own risk."""
        if not is_called_from_pygame():
            _warnings.warn(
                "The 'add' method is a pygame internal method and should not be called directly. "
                "Sprites are automatically added to the sprite group when created.",
                UserWarning,
                stacklevel=2,
            )
        super().add(*groups)

    def add_internal(self, group):
        """Add the sprite to a group internally (pygame internal method).
        Warning: This is a pygame internal method. Use at your own risk."""
        if not is_called_from_pygame():
            _warnings.warn(
                "The 'add_internal' method is a pygame internal method and should not be called directly.",
                UserWarning,
                stacklevel=2,
            )
        super().add_internal(group)

    def remove_internal(self, group):
        """Remove the sprite from a group internally (pygame internal method).
        Warning: This is a pygame internal method. Use at your own risk."""
        if not is_called_from_pygame():
            _warnings.warn(
                "The 'remove_internal' method is a pygame internal method and should not be called directly. "
                "Use the 'remove' method instead.",
                UserWarning,
                stacklevel=2,
            )
        super().remove_internal(group)

    def _draw_disabled_overlay(self, surface):
        """Dim *surface* in place with a translucent grey to signal disabled state."""
        overlay = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
        overlay.fill((200, 200, 200, 120))
        surface.blit(overlay, (0, 0))

    def _finalize_image(self, draw_image):
        """Scale *draw_image* by the sprite's size, then place it.

        The shared render tail: _hit_dims() scales the pymunk hit-shape by
        size, so the drawn image has to scale with it."""
        if self._size != 100:
            draw_image = _scale_to_percent(draw_image, self._size)
        self._place_image(draw_image)

    def _place_image(self, draw_image):
        """Apply transparency, rotate and centre *draw_image* on ``(x, y)``."""
        draw_image.set_alpha(round(self._transparency * 255 / 100))
        self._unrotated_size = draw_image.get_size()
        rect = draw_image.get_rect()
        pos = convert_pos(self.x, self.y)
        rect.x = pos[0] - rect.width // 2
        rect.y = pos[1] - rect.height // 2
        if self.physics is not None:
            angle_deg = _math.degrees(self.physics._pymunk_body.angle)
        else:  # Text renders once before Sprite.__init__ builds the body
            angle_deg = self._angle
        if angle_deg:
            self.image = pygame.transform.rotate(draw_image, angle_deg)
            self.rect = self.image.get_rect(center=rect.center)
        else:
            self.image = draw_image
            self.rect = rect

    # Whether the pymunk hit-shape is a circle. It is a property of the kind
    # of sprite, not of the sign of the radius: a circle built at a negative
    # size has to be a circle again when it grows back.
    _circular_hit_shape = False
    _scaled_by_size = False
    _unrotated_size = None

    def _hit_dims(self, size_factor):
        """Return ``(radius, width, height)``; *size_factor* applies if size scales the drawing."""
        width, height = self._unscaled_size()
        if not self._scaled_by_size:
            size_factor = 1
        return 0.0, float(width * size_factor), float(height * size_factor)

    def _unscaled_size(self):
        """Return the ``(width, height)`` the hit shape starts from: the drawing before it is turned."""
        if self._unrotated_size is None:
            return self.rect.size
        return self._unrotated_size

    @property
    def width(self):
        """Get the width of the sprite.
        :return: The width of the sprite."""
        return self.rect.width

    @property
    def height(self):
        """Get the height of the sprite.
        :return: The height of the sprite."""
        return self.rect.height

    @property
    def right(self):
        """Get the right of the sprite.
        :return: The right of the sprite."""
        return self.x + self.width / 2

    @right.setter
    def right(self, x):
        """Set the right of the sprite to a x-coordinate.
        :param x: The x-coordinate to set the right of the sprite to."""
        self.x = x - self.width / 2

    @property
    def left(self):
        """Get the left of the sprite.
        :return: The left of the sprite."""
        return self.x - self.width / 2

    @left.setter
    def left(self, x):
        """Set the left of the sprite to a x-coordinate.
        :param x: The x-coordinate to set the left of the sprite to."""
        self.x = x + self.width / 2

    @property
    def top(self):
        """Get the top of the sprite.
        :return: The top of the sprite."""
        return self.y + self.height / 2

    @top.setter
    def top(self, y):
        """Set the top of the sprite to a y-coordinate.
        :param y: The y-coordinate to set the top of the sprite to."""
        self.y = y - self.height / 2

    @property
    def bottom(self):
        """Get the bottom of the sprite.
        :return: The bottom of the sprite."""
        return self.y - self.height / 2

    @bottom.setter
    def bottom(self, y):
        """Set the bottom of the sprite to a y-coordinate.
        :param y: The y-coordinate to set the bottom of the sprite to."""
        self.y = y + self.height / 2

    def _pygame_x(self):
        return self.x + (screen.width / 2.0) - (self.rect.width / 2.0)

    def _pygame_y(self):
        return (screen.height / 2.0) - self.y - (self.rect.height / 2.0)

    # @decorator
    def when_clicked(self, callback, call_with_sprite=False):
        """Run a function when the sprite is clicked.
        :param callback: The function to run.
        :param call_with_sprite: Whether to call the function with the sprite as an argument.
        """
        return self.events.when_clicked(callback, call_with_sprite)

    # @decorator
    def when_click_released(self, callback, call_with_sprite=False):
        """Run a function when the sprite click is released.
        :param callback: The function to run.
        :param call_with_sprite: Whether to call the function with the sprite as an argument.
        """
        return self.events.when_click_released(callback, call_with_sprite)

    def when_touching(self, *sprites):
        """Run a function when the sprite starts touching another sprite.
        An async function runs as a task of its own, so its awaits do not hold up the game.
        :param sprites: The sprites to check if they're touching.
        """
        return self.events.when_touching(*sprites)

    def when_stopped_touching(self, *sprites):
        """Run a function when the sprite is no longer touching another sprite.
        An async function runs as a task of its own, so its awaits do not hold up the game.
        :param sprites: The sprites to check if they're touching.
        """
        return self.events.when_stopped_touching(*sprites)

    def when_touching_wall(self, callback=None, *, wall=None):
        """Run a function when the sprite starts touching the edge of the screen.
        An async function runs as a task of its own, so its awaits do not hold up the game.
        :param callback: The function to run.
        :param wall: Optional WallSide or list of WallSides to filter which walls trigger the callback.
        """
        return self.events.when_touching_wall(callback, wall=wall)

    def when_stopped_touching_wall(self, callback=None, *, wall=None):
        """Run a function when the sprite is no longer touching the edge of the screen.
        An async function runs as a task of its own, so its awaits do not hold up the game.
        :param callback: The function to run.
        :param wall: Optional WallSide or list of WallSides to filter which walls trigger the callback.
        """
        return self.events.when_stopped_touching_wall(callback, wall=wall)

    def _common_properties(self):
        # used with inheritance to clone
        return {
            "x": self._anchor_ox if self._anchor else self.x,
            "y": self._anchor_oy if self._anchor else self.y,
            "size": self.size,
            "transparency": self.transparency,
            "angle": self.angle,
            "anchor": self._anchor,
            "layer": self._layer,
        }

    def clone(self):
        """Clone the sprite.
        :return: The cloned sprite."""
        return self.__class__(image=self.image)

    def _save_and_clear_callbacks(self):
        """Save all physics-related callbacks for a sprite and clear them.

        Returns a dict mapping each CallbackType to a list of saved callbacks.
        """
        sprite_id = id(self)
        self.events.clear_all_touching()
        callback_types = [
            CallbackType.WHEN_TOUCHING,
            CallbackType.WHEN_TOUCHING_WALL,
            CallbackType.WHEN_STOPPED_TOUCHING,
            CallbackType.WHEN_STOPPED_TOUCHING_WALL,
        ]
        saved_callbacks = {
            callback_type: list(
                callback_manager.get_callback(callback_type, sprite_id) or []
            )
            for callback_type in callback_types
        }
        for callback_type in callback_types:
            callback_manager.remove_callbacks(callback_type, sprite_id)
        return saved_callbacks

    def _reregister_own_callbacks(self, saved_callbacks):
        """Re-register this sprite's own callbacks after physics recreation."""
        for wrapper, sprite in saved_callbacks[CallbackType.WHEN_TOUCHING]:
            self.when_touching(sprite)(wrapper.callback)
        for wrapper, wall_side in saved_callbacks[CallbackType.WHEN_TOUCHING_WALL]:
            self.when_touching_wall(wrapper.callback, wall=wall_side)
        for wrapper, sprite in saved_callbacks[CallbackType.WHEN_STOPPED_TOUCHING]:
            self.when_stopped_touching(sprite)(wrapper.callback)
        for wrapper, wall_side in saved_callbacks[
            CallbackType.WHEN_STOPPED_TOUCHING_WALL
        ]:
            self.when_stopped_touching_wall(wrapper.callback, wall=wall_side)

    def _reregister_dependent_callbacks(self):
        """Register the callbacks other sprites have on this one again, on its new shape."""
        for dependent in list(self.events._dependent_sprites):
            for callback_type, register in (
                (CallbackType.WHEN_TOUCHING, dependent.when_touching),
                (CallbackType.WHEN_STOPPED_TOUCHING, dependent.when_stopped_touching),
            ):
                for wrapper in callback_manager.take_callbacks_on(
                    callback_type, id(dependent), self
                ):
                    register(self)(wrapper.callback)

    def start_physics(
        self,
        can_move=True,
        stable=False,
        x_speed=0,
        y_speed=0,
        obeys_gravity=True,
        bounciness=1.0,
        mass=10,
        friction=0,
        sensor=False,
    ):
        """Start the physics simulation for this sprite.
        :param can_move: Whether the object can move.
        :param stable: Whether the object is stable.
        :param x_speed: The x-speed of the object.
        :param y_speed: The y-speed of the object.
        :param obeys_gravity: Whether the object obeys gravity.
        :param bounciness: The bounciness of the object.
        :param mass: The mass of the object.
        :param friction: The friction of the object.
        :param sensor: Whether the object is a sensor (detects collisions without blocking).
            UI widgets start out as sensors that physics sprites pass through.
            Calling start_physics() on one makes it solid, like any sprite,
            unless you pass ``sensor=True``; that holds even if you only meant
            to change, say, its bounciness.
        """
        if not self.alive():
            return

        saved_callbacks = self._save_and_clear_callbacks()

        if self.physics is not None:
            collision_registry.forget(self.physics._pymunk_shape)
            self.physics._remove()

        self.physics = _Physics(
            self,
            can_move,
            stable,
            x_speed,
            y_speed,
            obeys_gravity,
            bounciness,
            mass,
            friction,
            sensor=sensor,
        )

        self._reregister_own_callbacks(saved_callbacks)
        self._reregister_dependent_callbacks()

    def stop_physics(self):
        """Resets the physics to the starting situation"""
        self.start_physics(
            stable=True, obeys_gravity=False, sensor=self._sensor_by_default
        )
