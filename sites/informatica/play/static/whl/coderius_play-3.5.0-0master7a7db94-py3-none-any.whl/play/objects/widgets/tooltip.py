"""Tooltip — a text overlay that appears when hovering over a target sprite."""

import math as _math
import pygame

from play.objects.sprite import Sprite
from play.io.mouse import mouse
from play.utils import (
    color_name_to_rgb as _color_name_to_rgb,
    load_font as _load_font,
    render_text as _render_text,
)
from play.io.screen import convert_pos


class Tooltip(Sprite):
    """A floating text label that follows the mouse and is only visible while
    the mouse hovers over *target*.

    Usage::

        btn = play.new_button("Hover me")
        tip = play.new_tooltip("Click to continue", target=btn)
    """

    # A pure visual overlay: its automatic body is a sensor, so it never
    # blocks or shoves other sprites, also after stop_physics().
    _sensor_by_default = True

    def __init__(
        self,
        text="",
        target=None,
        offset_x=12,
        offset_y=-12,
        color="lightyellow",
        text_color="black",
        border_color="gray",
        font_size=15,
        font=None,
        padding=6,
        border_radius=4,
        transparency=100,
        layer=100,
    ):
        self._tooltip_text = text
        self._target = target
        self._offset_x = offset_x
        self._offset_y = offset_y
        self._tooltip_color = color
        self._text_color = text_color
        self._border_color = border_color
        self._tooltip_font = _load_font(font, font_size)
        self._font_size = font_size
        self._font_path = font
        self._padding = padding
        self._border_radius = border_radius
        self._transparency = transparency
        self._size = 100
        self._angle = 0
        self._image = None
        # Seed the rect with the bubble size so the pymunk hit-shape isn't a
        # degenerate 0x0 point (keeps the tooltip hit-testable, and consistent
        # with the other Sprite-based widgets).
        bw, bh = self._bubble_size()
        self.rect = pygame.Rect(0, 0, bw, bh)
        super().__init__(x=0, y=0, layer=layer)
        # Start hidden: hide() pauses physics so the body leaves the space
        # instead of lingering as an invisible collider.
        self.hide()
        self.update()

    def _render_label(self):
        """Render the text in one go; pygame lays out any newlines itself."""
        return _render_text(
            self._tooltip_font,
            self._tooltip_text,
            True,
            _color_name_to_rgb(self._text_color),
        )

    def _bubble_size(self):
        """Return the (width, height) of the tooltip bubble for the current text."""
        label = self._render_label()
        p = self._padding
        return max(1, label.get_width() + 2 * p), max(1, label.get_height() + 2 * p)

    def update(self):
        """Show/hide based on whether the mouse is over the target."""
        if self._target is not None and not self._target.alive():
            # The target was removed. Its cached pymunk shape still answers
            # point queries, so without this the bubble keeps reappearing over
            # empty space where the target used to be.
            self._target = None
            if not self._is_hidden:
                self.hide()
                self._should_recompute = True
        if self._target is not None:
            hovered = mouse.is_touching(self._target)
            if hovered and self._is_hidden:
                self.show()  # unpauses physics; marks dirty via __setattr__
                self._should_recompute = True
            elif not hovered and not self._is_hidden:
                self.hide()  # pauses physics so the body leaves the space
                self._should_recompute = True

        if not self._is_hidden:
            # Follow the mouse position; only recompute when it actually moved
            nx = mouse.x + self._offset_x
            ny = mouse.y + self._offset_y
            if nx != self._x or ny != self._y:
                self._x = nx
                self._y = ny
                self._should_recompute = True

        super().update()

    def _render(self):
        """Render the tooltip bubble."""
        label = self._render_label()
        p = self._padding
        w = label.get_width() + 2 * p
        h = label.get_height() + 2 * p

        draw_image = pygame.Surface((w, h), pygame.SRCALPHA)
        pygame.draw.rect(
            draw_image,
            _color_name_to_rgb(self._tooltip_color),
            (0, 0, w, h),
            border_radius=self._border_radius,
        )
        pygame.draw.rect(
            draw_image,
            _color_name_to_rgb(self._border_color),
            (0, 0, w, h),
            1,
            border_radius=self._border_radius,
        )

        draw_image.blit(label, (p, p))

        draw_image.set_alpha(round(self._transparency * 255 / 100))
        self._unrotated_size = (w, h)

        pos = convert_pos(self._x, self._y)
        centre_x = pos[0] + w // 2
        centre_y = pos[1] - h + h // 2
        # The tooltip follows the mouse by writing _x/_y directly (not the x/y
        # setters), so move the sensor body onto the visible bubble's centre;
        # otherwise its collision shape would stay stranded at the origin.
        self.physics._pymunk_body.position = (self._x + w // 2, self._y + h // 2)
        angle_deg = _math.degrees(self.physics._pymunk_body.angle)
        self.image = pygame.transform.rotate(draw_image, angle_deg)
        self.rect = self.image.get_rect(center=(centre_x, centre_y))

    # ── public API ────────────────────────────────────────────────────────────

    @property
    def text(self):
        """The tooltip text (may include newlines)."""
        return self._tooltip_text

    @text.setter
    def text(self, v):
        self._tooltip_text = v
        bw, bh = self._bubble_size()
        self.rect = pygame.Rect(self.rect.x, self.rect.y, bw, bh)
        self.physics._resize_shape()
        self._should_recompute = True

    @property
    def target(self):
        """The sprite this tooltip is attached to."""
        return self._target

    @target.setter
    def target(self, v):
        self._target = v

    def clone(self):
        return Tooltip(
            text=self._tooltip_text,
            target=self._target,
            offset_x=self._offset_x,
            offset_y=self._offset_y,
            color=self._tooltip_color,
            text_color=self._text_color,
            border_color=self._border_color,
            font_size=self._font_size,
            font=self._font_path,
            padding=self._padding,
            border_radius=self._border_radius,
            transparency=self._transparency,
            layer=self._layer,
        )
