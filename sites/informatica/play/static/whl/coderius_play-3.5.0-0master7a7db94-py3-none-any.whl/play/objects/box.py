"""This module contains the Box class, which represents a box in the game."""

import pygame
from play.objects.sprite import Sprite
from play.utils import color_name_to_rgb as _color_name_to_rgb


class Box(Sprite):
    _scaled_by_size = True

    def __init__(
        self,
        color="black",
        x=0,
        y=0,
        width=100,
        height=200,
        border_color="light blue",
        border_width=0,
        border_radius=0,
        transparency=100,
        size=100,
        angle=0,
        anchor=None,
        layer=0,
    ):
        self._color = color
        self._width = width
        self._height = height
        self._border_color = border_color
        self._border_width = border_width
        self._border_radius = border_radius
        self._transparency = transparency
        self._size = size
        self._angle = angle
        self.rect = pygame.Rect(0, 0, 0, 0)

        super().__init__(x=x, y=y, anchor=anchor, layer=layer)
        # Render only. Subclasses override update() with input handling, and
        # the frame's click state is still live during __init__, so self.update()
        # would let a widget built under the cursor activate itself on creation.
        super().update()

    def _unscaled_size(self):
        """Return ``(width, height)`` before size and angle apply, a negative side as 0."""
        return max(self._width, 0), max(self._height, 0)

    def _render(self):
        """Draw the box surface with border, scale, alpha, and rotation."""
        width, height = self._unscaled_size()
        draw_image = pygame.Surface((width, height), pygame.SRCALPHA)

        if self._border_width > 0:
            pygame.draw.rect(
                draw_image,
                _color_name_to_rgb(self._border_color),
                (0, 0, width, height),
                self._border_width,
                border_radius=self._border_radius,
            )

        pygame.draw.rect(
            draw_image,
            _color_name_to_rgb(self._color),
            (
                self._border_width,
                self._border_width,
                width - 2 * self._border_width,
                height - 2 * self._border_width,
            ),
            border_radius=max(self._border_radius - self._border_width, 0),
        )

        self._finalize_image(draw_image)

    ##### width #####
    @property
    def width(self):
        """The width of the box.
        :return: The width of the box."""
        return self._width

    @width.setter
    def width(self, _width):
        """Set the width of the box.
        :param _width: The new width of the box."""
        self._width = _width
        self._should_recompute = True
        self.physics._resize_shape()

    ##### height #####
    @property
    def height(self):
        """The height of the box.
        :return: The height of the box."""
        return self._height

    @height.setter
    def height(self, _height):
        """Set the height of the box.
        :param _height: The new height of the box."""
        self._height = _height
        self._should_recompute = True
        self.physics._resize_shape()

    ##### color #####
    @property
    def color(self):
        """The color of the box.
        :return: The color of the box."""
        return self._color

    @color.setter
    def color(self, _color):
        """Set the color of the box.
        :param _color: The new color of the box."""
        _color_name_to_rgb(_color)
        self._color = _color

    ##### border_color #####
    @property
    def border_color(self):
        """The color of the box's border.
        :return: The color of the box's border."""
        return self._border_color

    @border_color.setter
    def border_color(self, _border_color):
        """Set the color of the box's border.
        :param _border_color: The new color of the box's border."""
        _color_name_to_rgb(_border_color)
        self._border_color = _border_color

    ##### border_width #####
    @property
    def border_width(self):
        """The width of the box's border.
        :return: The width of the box's border."""
        return self._border_width

    @border_width.setter
    def border_width(self, _border_width):
        """Set the width of the box's border.
        :param _border_width: The new width of the box's border."""
        self._border_width = _border_width

    ##### border_radius #####
    @property
    def border_radius(self):
        """The radius of the box's border.
        :return: The radius of the box's border."""
        return self._border_radius

    @border_radius.setter
    def border_radius(self, _border_radius):
        """Set the radius of the box's border.
        :param _border_radius: The new radius of the box's border."""
        self._border_radius = _border_radius

    def clone(self):
        """Create a copy of the box.
        :return: A copy of the box."""
        return self.__class__(
            color=self.color,
            width=self.width,
            height=self.height,
            border_color=self.border_color,
            border_width=self.border_width,
            border_radius=self.border_radius,
            **self._common_properties()
        )
