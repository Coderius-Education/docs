"""Handles custom music/sound being played."""

import pygame
from play.io.logging import play_logger as logger


def _init_mixer():
    """Start the mixer; on a machine without an audio device, warn and return False."""
    try:
        pygame.mixer.init()
    except pygame.error as error:
        logger.warning("Sounds will be silent: no audio device was found (%s)", error)
        return False
    return True


class Sound:
    """A sound or music file that can be played, paused and stopped."""

    def __init__(self, file_name, volume=1.0, loops=0):
        """
        Initialize the Sound object.
        :param file_name: The sound file to load.
        :param volume: The initial volume (0.0 to 1.0).
        :param loops: Number of times to loop the sound (-1 for infinite, 0 for no loop).
        """
        self.sound = None
        self.channel = None
        self.file_path = file_name
        self._volume = volume
        self.loops = loops
        self.is_paused = False
        if _init_mixer():
            self.load(file_name)

    def load(self, file_name):
        """Load a sound file."""
        try:
            self.sound = pygame.mixer.Sound(file_name)
        except (FileNotFoundError, pygame.error):
            # pygame raises pygame.error for a corrupt or unreadable file, not
            # just FileNotFoundError for a missing one.
            logger.error("Could not load sound file '%s'", file_name, exc_info=True)
            return
        self.sound.set_volume(self._volume)
        logger.info("Loaded sound file")

    def play(self):
        """Play the loaded sound with the specified loop settings, or resume a paused sound."""
        if not self.sound:
            logger.warning("No sound loaded. Use the 'load' method first.")
            return

        if self.is_paused and self.channel is not None:
            self.channel.unpause()
            self.is_paused = False
            return

        # Stop any existing playback before starting a new one so we don't
        # leak an untracked channel.
        if self.channel is not None and self.channel.get_busy():
            self.channel.stop()

        self.channel = pygame.mixer.find_channel()
        if self.channel is None:
            logger.warning("No available channels to play the sound.")
            return

        self.channel.play(self.sound, loops=self.loops)

    def pause(self):
        """Pause the sound."""
        if self.channel is None:
            return
        if self.channel.get_busy():
            self.channel.pause()
            self.is_paused = True

    @property
    def length(self):
        """Returns the length of the sound in seconds as a float"""
        if self.sound is None:
            return 0.0
        return round(self.sound.get_length(), 2)

    def stop(self):
        """Stop current channel"""
        self.is_paused = False
        if self.channel is None:
            return
        self.channel.stop()

    @property
    def volume(self):
        """Get the current volume of the sound."""
        if not self.sound:
            logger.warning("No sound loaded. Use the 'load' method first.")
            return self._volume
        return self.sound.get_volume()

    @volume.setter
    def volume(self, volume):
        """Set the volume of the sound (0.0 to 1.0)."""
        if not 0.0 <= volume <= 1.0:
            logger.warning("Volume must be between 0.0 and 1.0")
        self._volume = min(max(volume, 0.0), 1.0)
        if self.sound:
            self.sound.set_volume(self._volume)

    @property
    def playing(self):
        """Check if the sound is currently playing."""
        if self.channel:
            return self.channel.get_busy()
        return False
