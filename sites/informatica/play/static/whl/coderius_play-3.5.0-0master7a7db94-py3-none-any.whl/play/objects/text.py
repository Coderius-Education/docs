"""This module contains the Text class, which is a text string in the game."""

import os
import pygame
from play.objects.sprite import Sprite
from play.utils import (
    color_name_to_rgb as _color_name_to_rgb,
    render_text as _render_text,
)
from play.io.logging import play_logger


class Text(Sprite):
    _scaled_by_size = True

    def __init__(
        self,
        words="",
        x=0,
        y=0,
        font="default",
        font_size=50,
        color="black",
        angle=0,
        transparency=100,
        size=100,
        anchor=None,
        layer=0,
    ):
        Sprite._init_anchor_attrs(self, x, y, anchor, layer)
        self._font = font
        self._font_size = font_size

        self._load_font(font, font_size)
        self._words = str(words)
        self._color = color

        self._x = 0 if anchor else x
        self._y = 0 if anchor else y

        self._size = size
        self._angle = angle
        self._transparency = transparency

        self._is_clicked = False
        self._is_hidden = False

        self.rect = pygame.Rect(0, 0, 0, 0)
        self._should_recompute = True
        self.update()  # Must compute rect size before start_physics
        super().__init__(x=x, y=y, anchor=anchor, layer=layer)

    def _render(self):
        """Render the text surface with scale, rotation, and alpha."""
        draw_image = _render_text(
            self._pygame_font, self._words, True, _color_name_to_rgb(self._color)
        )
        self._finalize_image(draw_image)

    def _unscaled_size(self):
        """Return the size of the rendered words before size and angle apply."""
        return _render_text(self._pygame_font, self._words, True, (0, 0, 0)).get_size()

    def clone(self):
        return self.__class__(
            words=self.words,
            font=self.font,
            font_size=self.font_size,
            color=self.color,
            **self._common_properties(),
        )

    @property
    def words(self):
        """Get the words of the text object."""
        return self._words

    @words.setter
    def words(self, string):
        """Set the words of the text object."""
        self._words = str(string)
        self.physics._resize_shape()

    @property
    def font(self):
        """Get the font of the text object."""
        return self._font

    @font.setter
    def font(self, font_name):
        """Set the font of the text object. This will load the font dynamically."""
        self._font = font_name
        self._load_font(font_name, self._font_size)
        self.physics._resize_shape()

    @property
    def font_size(self):
        """Get the font size of the text object."""
        return self._font_size

    @font_size.setter
    def font_size(self, size):
        """Set the font size of the text object."""
        self._font_size = size
        self._load_font(self._font, size)
        self.physics._resize_shape()

    @property
    def color(self):
        """Get the color of the text object."""
        return self._color

    @color.setter
    def color(self, color_):
        """Set the color of the text object."""
        _color_name_to_rgb(color_)
        self._color = color_

    def _load_font(self, font_name, font_size):
        """Helper method to load a font, either from a file or system."""
        font_size = round(font_size)
        if font_name in ("default", None):
            self._pygame_font = pygame.font.Font(
                pygame.font.get_default_font(), font_size
            )
        elif os.path.isfile(font_name):
            self._pygame_font = pygame.font.Font(font_name, font_size)
        else:
            matched = pygame.font.match_font(font_name)
            if matched:
                self._pygame_font = pygame.font.Font(matched, font_size)
            else:
                play_logger.warning(
                    "Font '%s' not found, using default font", font_name
                )
                self._pygame_font = pygame.font.Font(
                    pygame.font.get_default_font(), font_size
                )
