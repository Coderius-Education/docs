"""Components for the component-based Sprite design."""

from play.callback import callback_manager, CallbackType
from play.callback.collision_callbacks import (
    collision_registry,
    CollisionType,
    WallSide,
)
from play.globals import globals_list
from play.utils.async_helpers import make_async
from play.callback.callback_helpers import contact_callback, run_async_callback


class EventComponent:
    """Manages event callbacks and collision detection checks for a sprite."""

    def __init__(self, sprite):
        self._sprite = sprite
        self._touching_callback = {}
        self._new_touching = {}
        self._fired_this_frame = set()
        self._stopped_callback = {}
        self._walls_touched_with_area = set()
        self._contacts_running = set()
        self._dependent_sprites = set()
        self._is_clicked = False

    @property
    def is_clicked(self):
        """Get whether the sprite is currently clicked.
        :return: Whether the sprite is clicked."""
        return self._is_clicked

    @is_clicked.setter
    def is_clicked(self, value):
        """Set whether the sprite is currently clicked."""
        self._is_clicked = value

    def set_touching(self, key, callback, other=None):
        """Record an active touching collision.
        :param key: Collision key (e.g. shape collision_id or (CollisionType, WallSide)).
        :param callback: The callback to store.
        :param other: The sprite being touched, or None for a wall."""
        self._touching_callback[key] = (callback, other)
        self._new_touching[key] = (callback, other)
        collision_registry.mark_changed(self._sprite)

    def clear_touching(self, key):
        """Remove an active touching collision record.
        :param key: Collision key to remove."""
        del self._touching_callback[key]

    def get_touching(self, key, default=None):
        """Retrieve an active touching collision callback.
        :param key: Collision key to look up.
        :param default: Value to return if key is absent."""
        if key not in self._touching_callback:
            return default
        return self._touching_callback[key][0]

    def clear_all_touching(self):
        """Drop every active touching collision.

        Used when the sprite's pymunk shape is replaced: the recorded keys
        belong to the old shape, so pymunk will never send the separate that
        would clear them and the callback would run forever."""
        self._touching_callback = {}
        self._new_touching = {}
        self._fired_this_frame = set()
        self._walls_touched_with_area = set()

    def wall_contact_began(self, wall):
        """Note that a contact with a wall began.
        :param wall: The wall's pymunk shape."""
        if self._sprite.physics._has_area:
            self._walls_touched_with_area.add(wall)

    def wall_contact_ended(self, wall):
        """Forget a contact with a wall that ended.
        :param wall: The wall's pymunk shape.
        :return: Whether the sprite had an area when the contact began or has one now.
        """
        had_area = wall in self._walls_touched_with_area
        self._walls_touched_with_area.discard(wall)
        return had_area or self._sprite.physics._has_area

    def set_stopped(self, key, callback):
        """Record a stopped-touching collision callback.
        :param key: Collision key.
        :param callback: The callback to store."""
        self._stopped_callback[key] = callback
        collision_registry.mark_changed(self._sprite)

    def new_touching_callbacks(self):
        """Return the callbacks of contacts that began since the last call."""
        contacts = self._new_touching
        self._fired_this_frame.update(contacts)
        self._new_touching = {}
        return [
            callback
            for callback, other in contacts.values()
            if self._can_touch_with(other)
        ]

    def touching_callbacks(self):
        """Return the callbacks still touching that have not run this frame."""
        callbacks = [
            callback
            for key, (callback, other) in self._touching_callback.items()
            if key not in self._fired_this_frame and self._can_touch_with(other)
        ]
        self._new_touching = {}
        self._fired_this_frame = set()
        return callbacks

    def _can_touch_with(self, other):
        """Whether this sprite and *other* (None for a wall) can both still touch."""
        return self._sprite._can_touch() and (other is None or other._can_touch())

    def stopped_callbacks(self):
        """Return all pending stopped-touching collision callbacks."""
        return list(self._stopped_callback.values())

    def clear_all_stopped(self):
        """Clear all pending stopped-touching collision callbacks."""
        self._stopped_callback = {}

    def when_clicked(self, callback, call_with_sprite=False):
        """Register a callback for when the sprite is clicked.
        :param callback: The async callback function.
        :param call_with_sprite: Pass the sprite into the callback if True."""
        async_callback = make_async(callback)

        async def wrapper():
            wrapper.is_running = True
            if call_with_sprite:
                await run_async_callback(async_callback, ["sprite"], [], self._sprite)
            else:
                await run_async_callback(async_callback, [], [])
            wrapper.is_running = False

        wrapper.is_running = False
        callback_manager.add_callback(
            CallbackType.WHEN_CLICKED_SPRITE, wrapper, id(self._sprite)
        )
        return wrapper

    def when_click_released(self, callback, call_with_sprite=False):
        """Register a callback for when a click on the sprite is released.
        :param callback: The async callback function.
        :param call_with_sprite: Pass the sprite into the callback if True."""
        async_callback = make_async(callback)

        async def wrapper():
            wrapper.is_running = True
            if call_with_sprite:
                await run_async_callback(async_callback, ["sprite"], [], self._sprite)
            else:
                await run_async_callback(async_callback, [], [])
            wrapper.is_running = False

        wrapper.is_running = False
        callback_manager.add_callback(
            CallbackType.WHEN_CLICK_RELEASED_SPRITE, wrapper, id(self._sprite)
        )
        return wrapper

    def when_touching(self, *sprites_to_check):
        """Register a callback for when the sprite is touching another sprite.
        :param sprites_to_check: Sprites to check for collision."""

        def decorator(func):
            for target in sprites_to_check:
                collision_registry.register(
                    self._sprite,
                    target,
                    self._sprite.physics._pymunk_shape,
                    target.physics._pymunk_shape,
                    contact_callback(
                        func,
                        contact=(target, True),
                        running=self._contacts_running,
                    ),
                    CollisionType.SPRITE,
                )

            async_func = make_async(func)

            async def wrapper():
                await run_async_callback(async_func, [], [])

            wrapper.callback = func
            for target in sprites_to_check:
                target.events._dependent_sprites.add(self._sprite)
                callback_manager.add_callback(
                    CallbackType.WHEN_TOUCHING, (wrapper, target), id(self._sprite)
                )
            return wrapper

        return decorator

    def when_stopped_touching(self, *sprites_to_check):
        """Register a callback for when the sprite is no longer touching another sprite.
        :param sprites_to_check: Sprites to check for collision separation."""

        def decorator(func):
            for target in sprites_to_check:
                collision_registry.register(
                    self._sprite,
                    target,
                    self._sprite.physics._pymunk_shape,
                    target.physics._pymunk_shape,
                    contact_callback(
                        func,
                        contact=(target, False),
                        running=self._contacts_running,
                    ),
                    CollisionType.SPRITE,
                    begin=False,
                )

            async_func = make_async(func)

            async def wrapper():
                await run_async_callback(async_func, [], [])

            wrapper.callback = func
            for target in sprites_to_check:
                target.events._dependent_sprites.add(self._sprite)
                callback_manager.add_callback(
                    CallbackType.WHEN_STOPPED_TOUCHING,
                    (wrapper, target),
                    id(self._sprite),
                )
            return wrapper

        return decorator

    def _register_wall_callbacks(self, func, wall, begin, callback_type):
        """Shared helper for when_touching_wall and when_stopped_touching_wall.
        :param func: The callback function.
        :param wall: Wall filter (None, WallSide, or list of WallSide).
        :param begin: True for begin-contact, False for separate.
        :param callback_type: The CallbackType to use for callback_manager."""
        if wall is None:
            walls_to_register = globals_list.walls
        elif isinstance(wall, WallSide):
            walls_to_register = [w for w in globals_list.walls if w.wall_side == wall]
        else:
            walls_to_register = [w for w in globals_list.walls if w.wall_side in wall]

        for wall_segment in walls_to_register:
            wall_side = wall_segment.wall_side

            wrapper = contact_callback(
                func,
                wall_side,
                contact=(wall_side, begin),
                running=self._contacts_running,
                optional_args=["wall"],
            )
            wrapper.callback = func

            collision_registry.register(
                self._sprite,
                None,
                self._sprite.physics._pymunk_shape,
                wall_segment,
                wrapper,
                CollisionType.WALL,
                begin=begin,
            )

            wrapper.wall_filter = wall
            callback_manager.add_callback(
                callback_type,
                (wrapper, wall_side),
                id(self._sprite),
            )
        return func

    def when_touching_wall(self, callback=None, *, wall=None):
        """Register a callback for when the sprite touches a wall.
        :param callback: Callback to run.
        :param wall: Optional specific wall or list of walls to check."""

        def decorator(func):
            return self._register_wall_callbacks(
                func, wall, True, CallbackType.WHEN_TOUCHING_WALL
            )

        if callback is not None:
            return decorator(callback)
        return decorator

    def when_stopped_touching_wall(self, callback=None, *, wall=None):
        """Register a callback for when the sprite is no longer touching a wall.
        :param callback: Callback to run.
        :param wall: Optional specific wall or list of walls to check."""

        def decorator(func):
            return self._register_wall_callbacks(
                func, wall, False, CallbackType.WHEN_STOPPED_TOUCHING_WALL
            )

        if callback is not None:
            return decorator(callback)
        return decorator
