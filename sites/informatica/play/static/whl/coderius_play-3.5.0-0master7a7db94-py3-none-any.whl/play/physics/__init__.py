"""This handles the physics of the game."""

import atexit as _atexit
import math as _math
import numbers as _numbers
import traceback as _traceback
from dataclasses import dataclass

import pygame
import pymunk as _pymunk

from play.globals import globals_list

_NO_AREA_CATEGORY = 0b1
_COLLIDES = _pymunk.ShapeFilter(
    mask=_pymunk.ShapeFilter.ALL_MASKS() ^ _NO_AREA_CATEGORY
)
_COLLIDES_WITH_WALLS_ONLY = _pymunk.ShapeFilter(
    categories=_NO_AREA_CATEGORY, mask=_COLLIDES.mask
)


class Physics:
    def __init__(
        self,
        sprite,
        can_move,
        stable,
        x_speed,
        y_speed,
        obeys_gravity,
        bounciness,
        mass,
        friction,
        sensor=False,
    ):
        """
        Examples of objects with different parameters:

            Blocks that can be knocked over (the default):
                can_move = True
                stable = False
                obeys_gravity = True
            Jumping platformer character:
                can_move = True
                stable = True (doesn't fall over)
                obeys_gravity = True
            Moving platform:
                can_move = True
                stable = True
                obeys_gravity = False
            Stationary platform:
                can_move = False
                (others don't matter)
            Sensor (detects collisions without blocking):
                sensor = True
        """
        _check_mass(mass, can_move)
        self.sprite = sprite
        self._can_move = can_move
        self._stable = stable
        self._x_speed = x_speed
        self._y_speed = y_speed
        self._obeys_gravity = obeys_gravity
        self._bounciness = bounciness
        self._mass = mass
        self._friction = friction
        self._sensor = sensor
        self._is_paused = False
        self._has_area = True

        self._make_pymunk()

    def _compute_body_type(self):
        """Determine the pymunk body type based on movement and stability properties."""
        if not self.can_move:
            return _pymunk.Body.STATIC
        # Special case: moving platforms that don't obey gravity in a gravity world
        if self.stable and not self.obeys_gravity and physics_space.gravity != (0, 0):
            return _pymunk.Body.KINEMATIC
        return _pymunk.Body.DYNAMIC

    def _hit_dims(self):
        """Ask the sprite for its hit shape as ``(radius, width, height)``, scaled by size."""
        return self.sprite._hit_dims(max(self.sprite._size, 0) / 100)

    def _moment(self, is_circle, radius, width, height):
        mass = self._mass if self.can_move else 0
        if self.stable:
            return float("inf")
        if is_circle:
            return _pymunk.moment_for_circle(mass, 0, radius, (0, 0))
        return _pymunk.moment_for_box(mass, (width, height))

    def _collision_dims(self, is_circle):
        """Return the shape's ``(radius, width, height)``; one without area is kept at 1x1."""
        radius, width, height = self._hit_dims()
        self._has_area = radius > 0 if is_circle else width > 0 and height > 0
        if self._has_area:
            return radius, width, height
        return 0.5, 1.0, 1.0

    def _collision_filter(self):
        """Return the filter for the shape: without area it collides with walls only."""
        return _COLLIDES if self._has_area else _COLLIDES_WITH_WALLS_ONLY

    def _make_pymunk(self):
        """Build the body and shape once, at construction. Later changes to the
        sprite's size or physics settings are applied in place by
        :meth:`_resize_shape` and :meth:`_retype_body`."""
        is_circle = self.sprite._circular_hit_shape
        radius, width, height = self._collision_dims(is_circle)
        mass = self._mass if self.can_move else 0

        self._pymunk_body = _pymunk.Body(
            mass,
            self._moment(is_circle, radius, width, height),
            body_type=self._compute_body_type(),
        )
        self._pymunk_body.position = self.sprite.x, self.sprite.y
        self._pymunk_body.angle = _math.radians(self.sprite.angle)

        if self.can_move:
            self._pymunk_body.velocity = (self._x_speed, self._y_speed)

        if not self.obeys_gravity:
            self._pymunk_body.velocity_func = lambda body, gravity, damping, dt: None

        if is_circle:
            self._pymunk_shape = _pymunk.Circle(self._pymunk_body, radius, (0, 0))
        else:
            self._pymunk_shape = _pymunk.Poly.create_box(
                self._pymunk_body, (width, height)
            )

        self._pymunk_shape.filter = self._collision_filter()
        self._pymunk_shape.elasticity = pygame.math.clamp(self.bounciness, 0, 0.9999)
        self._pymunk_shape.friction = self._friction
        self._pymunk_shape.sensor = self._sensor
        self._pymunk_shape._play_sprite = None
        self._pymunk_shape._play_collision_type_set = False
        self._pymunk_shape.wall_side = None
        self._pymunk_shape.collision_id = None

        if not self._is_paused:
            physics_space.add(self._pymunk_body, self._pymunk_shape)

    def _resize_shape(self):
        """Fit the shape to the sprite's current hit dimensions, in place.

        The body and shape objects survive, so their collision_type, sensor
        flag and place in the collision registry need no bookkeeping. pymunk
        calls these setters unsafe because a shape that grows into another
        does not push it away as a moving one would; that is exactly what a
        rebuilt shape did too.
        """
        shape = self._pymunk_shape
        is_circle = isinstance(shape, _pymunk.Circle)
        radius, width, height = self._collision_dims(is_circle)
        if is_circle:
            shape.unsafe_set_radius(radius)
        else:
            shape.unsafe_set_vertices(_box_vertices(width, height))
        shape.filter = self._collision_filter()
        shape.cache_bb()
        if not self._is_paused:
            physics_space.reindex_shape(shape)
        if self._pymunk_body.body_type == _pymunk.Body.DYNAMIC:
            self._pymunk_body.moment = self._moment(is_circle, radius, width, height)

    def _retype_body(self):
        """Give the body the type its settings call for, in place.

        pymunk zeroes the mass and moment of a body that becomes dynamic, so
        both are set again afterwards; static and kinematic bodies take
        neither (Chipmunk aborts the process rather than raise on it).

        Never call this while the space is stepping, i.e. from inside a pymunk
        collision handler: Chipmunk aborts the process on a type change then.
        play's handlers only queue callbacks, which run after the step.
        """
        body = self._pymunk_body
        body.body_type = self._compute_body_type()
        if body.body_type == _pymunk.Body.DYNAMIC and self._mass > 0:
            body.mass = self._mass
        self._resize_shape()
        if self.can_move:
            body.velocity = (self._x_speed, self._y_speed)

    def clone(self, sprite):
        """
        Clone the physics object.
        :param sprite: The sprite to clone.
        """
        return self.__class__(
            sprite=sprite,
            can_move=self.can_move,
            x_speed=self.x_speed,
            y_speed=self.y_speed,
            obeys_gravity=self.obeys_gravity,
            bounciness=self.bounciness,
            mass=self.mass,
            friction=self._friction,
            stable=self.stable,
            sensor=self.sensor,
        )

    def pause(self):
        """Pause the object."""
        if self._is_paused:
            return
        self._remove()  # Remove first, before setting flag
        self._is_paused = True

    def unpause(self):
        """Unpause the object."""
        if not self._is_paused:
            return
        self._is_paused = False
        physics_space.add(self._pymunk_body, self._pymunk_shape)

    def _remove(self):
        if self._is_paused:
            return  # Already removed from space
        physics_space.remove(self._pymunk_body)
        physics_space.remove(self._pymunk_shape)

    @property
    def can_move(self):
        """Check if the object can move.
        :return: True if the object can move, False otherwise."""
        return self._can_move

    @can_move.setter
    def can_move(self, _can_move):
        prev_can_move = self._can_move
        _check_mass(self._mass, _can_move)
        self._can_move = _can_move
        if prev_can_move != _can_move:
            self._retype_body()

    @property
    def x_speed(self):
        """Get the x-speed of the object.
        :return: The x-speed of the object."""
        return self._x_speed

    @x_speed.setter
    def x_speed(self, _x_speed):
        self._x_speed = _x_speed
        self._pymunk_body.velocity = self._x_speed, self._pymunk_body.velocity[1]

    @property
    def y_speed(self):
        """Get the y-speed of the object.
        :return: The y-speed of the object."""
        return self._y_speed

    @y_speed.setter
    def y_speed(self, _y_speed):
        self._y_speed = _y_speed
        self._pymunk_body.velocity = self._pymunk_body.velocity[0], self._y_speed

    @property
    def bounciness(self):
        """Get the bounciness of the object.
        :return: The bounciness of the object."""
        return self._bounciness

    @bounciness.setter
    def bounciness(self, _bounciness):
        self._bounciness = _bounciness
        self._pymunk_shape.elasticity = pygame.math.clamp(self._bounciness, 0, 0.9999)

    @property
    def stable(self):
        """Check if the object is stable.
        :return: True if the object is stable, False otherwise."""
        return self._stable

    @stable.setter
    def stable(self, _stable):
        prev_stable = self._stable
        self._stable = _stable
        if self._stable != prev_stable:
            self._retype_body()

    @property
    def mass(self):
        """Get the mass of the object.
        :return: The mass of the object."""
        return self._mass

    @mass.setter
    def mass(self, _mass):
        """Set the mass of the object.
        :param _mass: The mass of the object."""
        _check_mass(_mass, self._can_move)
        self._mass = _mass
        if self._pymunk_body.body_type == _pymunk.Body.DYNAMIC:
            self._pymunk_body.mass = _mass

    @property
    def friction(self):
        """Get the friction of the object.
        :return: The friction of the object."""
        return self._friction

    @friction.setter
    def friction(self, _friction):
        self._friction = _friction
        self._pymunk_shape.friction = _friction

    @property
    def sensor(self):
        """Check if the object is a sensor.
        :return: True if the object is a sensor, False otherwise."""
        return self._pymunk_shape.sensor

    @sensor.setter
    def sensor(self, value):
        self._sensor = value
        self._pymunk_shape.sensor = value

    @property
    def obeys_gravity(self):
        """Check if the object obeys gravity.
        :return: True if the object obeys gravity, False otherwise."""
        return self._obeys_gravity

    @obeys_gravity.setter
    def obeys_gravity(self, _obeys_gravity):
        self._obeys_gravity = _obeys_gravity
        if _obeys_gravity:
            self._pymunk_body.velocity_func = _pymunk.Body.update_velocity
        else:
            self._pymunk_body.velocity_func = lambda body, gravity, damping, dt: None
        if self._compute_body_type() != self._pymunk_body.body_type:
            self._retype_body()


def _check_mass(mass, can_move):
    """Raise a student-readable error for a mass pymunk cannot use."""
    if (
        isinstance(mass, bool)
        or not isinstance(mass, _numbers.Real)
        or not 0 <= mass < _math.inf
        or (mass == 0 and can_move)
    ):
        raise ValueError(
            f"""The mass of a sprite has to be a number above 0, but it was set to {mass!r}.
Try a value like 10, which is the mass play uses when you don't give one."""
        )


def _box_vertices(width, height):
    """The corners of a centred box, in the order Poly.create_box uses."""
    half_w, half_h = width / 2, height / 2
    return [(half_w, -half_h), (half_w, half_h), (-half_w, half_h), (-half_w, -half_h)]


@dataclass
class _Gravity:
    """The gravity of the game."""

    vertical: int = -100
    horizontal: int = 0


globals_list.gravity = _Gravity()
physics_space = _pymunk.Space()
physics_space.sleep_time_threshold = float("inf")
physics_space.idle_speed_threshold = 0
physics_space.gravity = globals_list.gravity.horizontal, globals_list.gravity.vertical


def _keep_colliding(begin):
    """Wrap a pymunk 6 begin handler so the shapes still collide when it raises."""

    def begin_and_collide(arbiter, space, data):
        try:
            begin(arbiter, space, data)
        except Exception:  # pylint: disable=broad-exception-caught
            _traceback.print_exc()
        return True

    return begin_and_collide


def on_every_collision(begin, separate, space=physics_space):
    """Call *begin* when any two shapes start touching and *separate* when they stop.
    :param begin: Called with ``(arbiter, space, data)``; the shapes collide whatever it returns.
    :param separate: Called with ``(arbiter, space, data)``.
    :param space: The pymunk space to watch; play's own by default."""
    if _pymunk.version.startswith("6."):
        handler = space.add_default_collision_handler()
        handler.begin = _keep_colliding(begin)
        handler.separate = separate
    else:
        space.on_collision(begin=begin, separate=separate)


@_atexit.register
def _empty_physics_space():
    """Empty the space at exit, while pymunk can still detach what is in it."""
    physics_space.remove(*physics_space.shapes, *physics_space.bodies)


def set_gravity(vertical=-100, horizontal=None):
    """
    Set the gravity of the game.
    :param vertical: The vertical gravity of the game.
    :param horizontal: The horizontal gravity of the game.
    """
    globals_list.gravity.vertical = vertical
    if horizontal is not None:
        globals_list.gravity.horizontal = horizontal

    physics_space.gravity = (
        globals_list.gravity.horizontal,
        globals_list.gravity.vertical,
    )


def set_physics_simulation_steps(num_steps: int) -> None:
    """
    Set the number of simulation steps for the physics engine.
    :param num_steps: The number of simulation steps.
    """
    globals_list.num_sim_steps = num_steps
