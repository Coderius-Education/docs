"""Core game loop and event handling functions."""

import pygame

from play.core.controller_loop import (
    controller_state,
    handle_controller as _handle_controller,
    handle_controller_events as _handle_controller_events,
)
from play.core.game_loop_wrapper import listen_to_failure
from play.core.keyboard_loop import (
    handle_keyboard as _handle_keyboard,
    handle_keyboard_events as _handle_keyboard_events,
)
from play.core.mouse_loop import (
    handle_mouse_loop as _handle_mouse_loop,
    handle_mouse_events as _handle_mouse_events,
    mouse_state,
)
from play.io.mouse import mouse
from play.core.physics_loop import simulate_physics
from play.core.sprites_loop import update_sprites as _update_sprites
from play.callback import callback_manager, CallbackType
from play.globals import globals_list, ProgramState
from play.io.screen import screen, rebuild_walls as _rebuild_walls
from play.loop import create_task as _create_task, stop_loop as _stop_loop
from play.io.keypress import keyboard_state
from play.objects.widgets.text_input_registry import (
    dispatch_text as _dispatch_text_input,
    dispatch_keydown as _dispatch_text_keydown,
)

_clock = pygame.time.Clock()


def _handle_pygame_events():
    """Handle pygame events in the game loop."""
    for event in pygame.event.get():
        if event.type == pygame.QUIT or (
            event.type == pygame.KEYDOWN
            and event.key == pygame.K_q
            and (
                pygame.key.get_mods() & pygame.KMOD_META
                or pygame.key.get_mods() & pygame.KMOD_CTRL
            )
        ):
            # quitting by clicking window's close button or pressing ctrl+q / command+q
            _stop_loop()
            return False

        # Skip KEYDOWN recording while a TextInput is focused so typed characters
        # don't accumulate in keyboard_state and leak into game callbacks.
        # KEYUP is still processed to keep keyboard_state.pressed consistent.
        if not globals_list.focused_text_input or event.type == pygame.KEYUP:
            _handle_keyboard_events(event)
        _handle_mouse_events(event)
        _handle_controller_events(event)

        if event.type == pygame.TEXTINPUT:
            _dispatch_text_input(event.text)
        elif event.type == pygame.KEYDOWN:
            _dispatch_text_keydown(event)

        if event.type == pygame.VIDEORESIZE:
            screen._set_size(event.w, event.h)
            callback_manager.run_callbacks(CallbackType.WHEN_RESIZED)

    return True


@listen_to_failure()
async def game_loop():
    """The main game loop."""
    if globals_list.program_state is ProgramState.STOPPED:
        return
    keyboard_state.clear()
    mouse_state.clear()
    controller_state.clear()

    _clock.tick(globals_list.frame_rate)

    if not _handle_pygame_events():
        return

    # A focused TextInput captures the keyboard exclusively: every
    # @when_key_pressed / while-pressed / released callback and key poll is
    # suspended until the field is blurred (click elsewhere, Escape, or Enter).
    if not globals_list.focused_text_input:
        await _handle_keyboard()

    if (
        mouse_state.click_happened
        or mouse_state.click_release_happened
        or mouse._is_clicked
    ):
        await _handle_mouse_loop()

    if controller_state.any():
        await _handle_controller()

    #############################
    # physics simulation
    #############################
    await simulate_physics()

    if globals_list.backdrop_type == "color":
        globals_list.display.fill(globals_list.backdrop)
    elif globals_list.backdrop_type == "image":
        globals_list.display.blit(
            globals_list.backdrop,
            (0, 0),
        )
    else:
        globals_list.display.fill((255, 255, 255))

    await _update_sprites()

    pygame.display.flip()

    # @repeat_forever callbacks
    await callback_manager.run_callbacks_inline(CallbackType.REPEAT_FOREVER)
    _create_task(game_loop())
