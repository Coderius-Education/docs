"""This module contains the controller loop, which handles controller events in the game loop."""

from collections import defaultdict
import pygame

from play.callback import callback_manager, CallbackType
from play.io.controllers import controllers


class ControllerState:
    """Class to manage the state of the controller."""

    def __init__(self):
        self.buttons_pressed = defaultdict(set)
        self.buttons_pressed_this_frame = defaultdict(set)
        self.buttons_released = defaultdict(set)
        self.axes_moved = defaultdict(list)

    def clear(self):
        """Clear the per-frame controller events for the next frame."""
        self.buttons_pressed_this_frame.clear()
        self.buttons_released.clear()
        self.axes_moved.clear()

    def any(self):
        """Check if any controller activity is present.

        Note: `buttons_pressed` persists across frames (held state), so this
        returns True every frame a button is held — not just on the press frame.
        Use `buttons_pressed_this_frame` to check for new presses only."""
        return self.buttons_pressed or self.buttons_released or self.axes_moved


controller_state = ControllerState()

_CONTROLLER_EVENTS = (
    pygame.JOYAXISMOTION,
    pygame.JOYBUTTONDOWN,
    pygame.JOYBUTTONUP,
    pygame.JOYDEVICEREMOVED,
)


def handle_controller_events(event):
    """Handle controller events in the game loop.
    :param event: The event to handle."""
    if event.type == pygame.JOYDEVICEADDED:
        controllers._connect(event.device_index)
        return
    if event.type not in _CONTROLLER_EVENTS:
        return
    index = controllers._index_of(event.instance_id)
    if event.type == pygame.JOYAXISMOTION:
        controller_state.axes_moved[index].append(
            {"axis": event.axis, "value": round(event.value)}
        )
    if event.type == pygame.JOYBUTTONDOWN:
        controller_state.buttons_pressed[index].add(event.button)
        controller_state.buttons_pressed_this_frame[index].add(event.button)
    if event.type == pygame.JOYBUTTONUP:
        controller_state.buttons_released[index].add(event.button)
        controller_state.buttons_pressed[index].discard(event.button)
        if not controller_state.buttons_pressed[index]:
            del controller_state.buttons_pressed[index]
    if event.type == pygame.JOYDEVICEREMOVED:
        controller_state.buttons_pressed.pop(index, None)
        controller_state.buttons_pressed_this_frame.pop(index, None)
        controllers._disconnect(event.instance_id)


async def handle_controller():
    """Handle controller events in the game loop."""
    ############################################################
    # @controller.when_button_pressed and @controller.when_any_button_pressed
    ############################################################
    if controller_state.buttons_pressed_this_frame:
        for (
            controller_id,
            buttons,
        ) in controller_state.buttons_pressed_this_frame.items():
            await callback_manager.run_callbacks_with_filter(
                callback_type=CallbackType.WHEN_CONTROLLER_BUTTON_PRESSED,
                activated_states=buttons,
                required_args=["button"],
                property_filter={"controller": controller_id},
                held_states=controller_state.buttons_pressed.get(controller_id, set())
                | buttons,
            )

    ############################################################
    # @controller.when_button_released
    ############################################################
    if controller_state.buttons_released:
        for controller_id, buttons in controller_state.buttons_released.items():
            await callback_manager.run_callbacks_with_filter(
                callback_type=CallbackType.WHEN_CONTROLLER_BUTTON_RELEASED,
                activated_states=buttons,
                required_args=["button"],
                property_filter={"controller": controller_id},
            )

    ############################################################
    # @controller.while_button_pressed callbacks
    # Fire every frame for all currently held buttons
    ############################################################
    if controller_state.buttons_pressed:
        for controller_id, buttons in controller_state.buttons_pressed.items():
            await callback_manager.run_callbacks_with_filter(
                callback_type=CallbackType.WHILE_CONTROLLER_BUTTON_PRESSED,
                activated_states=buttons,
                required_args=["button"],
                property_filter={"controller": controller_id},
            )

    ############################################################
    # @controller.when_axis_moved
    ############################################################
    if controller_state.axes_moved:
        for controller_id, axes_events in controller_state.axes_moved.items():
            for axis_event in axes_events:
                await callback_manager.run_callbacks_with_filter(
                    CallbackType.WHEN_CONTROLLER_AXIS_MOVED,  # callback type
                    [axis_event["axis"]],  # activated states
                    axis_event["value"],  # value
                    required_args=["axis", "value"],
                    property_filter={"controller": controller_id},
                )
        controller_state.axes_moved.clear()
