"""This module contains the main loop for updating sprites and running their events."""

import math as _math

from play.core.mouse_loop import mouse_state
from play.callback import callback_manager, CallbackType
from play.callback.callback_helpers import run_any_async_callback
from play.callback.collision_callbacks import collision_registry
from play.globals import globals_list
from play.io.mouse import mouse

# Track which sprite was clicked for when_click_released events
_clicked_sprites = set()


def update_sprite_physics(sprite):
    """Update a sprite's position and angle from its physics body.

    Syncs the sprite's x, y, angle, and speed from the pymunk physics simulation.
    NaN values from the physics body are ignored to handle edge cases when
    changing sprite.physics.can_move.
    """
    body = sprite.physics._pymunk_body
    angle = _math.degrees(body.angle)
    if not _math.isnan(body.position.x):
        sprite._x = body.position.x
    if not _math.isnan(body.position.y):
        sprite._y = body.position.y

    if not _math.isnan(angle):
        sprite.angle = angle
    sprite.physics._x_speed, sprite.physics._y_speed = body.velocity


def _sync_moving_sprites(sprites):
    """Bring every moving sprite up to date with its physics body."""
    for sprite in sprites:
        if sprite.physics.can_move:
            update_sprite_physics(sprite)


async def handle_new_contacts():
    """After a physics sub-step: run the contacts that just began or ended."""
    changed = collision_registry.take_changed_sprites()
    if not changed:
        return
    sprites = globals_list.sprites_group.sprites()
    _sync_moving_sprites(sprites)
    for sprite in sprites:
        if sprite in changed:
            await run_any_async_callback(sprite.events.new_touching_callbacks(), [], [])
            await run_any_async_callback(sprite.events.stopped_callbacks(), [], [])
            sprite.events.clear_all_stopped()


async def run_sprite_callbacks(sprite):
    """Run touching and stopped callbacks for a sprite."""
    await run_any_async_callback(sprite.events.touching_callbacks(), [], [])
    await run_any_async_callback(sprite.events.stopped_callbacks(), [], [])
    sprite.events.clear_all_stopped()


def handle_sprite_click(sprite):
    """Handle click tracking and when_clicked events for a sprite.

    Tracks which sprite was clicked (for later click-release detection)
    and fires when_clicked callbacks.
    """
    if mouse.is_touching(sprite) and mouse_state.click_hits(sprite):
        _clicked_sprites.add(sprite)
        sprite.events.is_clicked = True
        callback_manager.run_callbacks(
            CallbackType.WHEN_CLICKED_SPRITE, callback_discriminator=id(sprite)
        )


def handle_sprite_click_released(sprite):
    """Handle when_click_released events for a sprite.

    Fires when the mouse button is released while touching the same sprite
    that was originally clicked.
    """
    if (
        mouse_state.click_release_happened
        and mouse.is_touching(sprite)
        and sprite in _clicked_sprites
    ):
        callback_manager.run_callbacks(
            CallbackType.WHEN_CLICK_RELEASED_SPRITE,
            callback_discriminator=id(sprite),
        )


def clear_click_tracking():
    """Clear the clicked sprite tracking after a release event."""
    _clicked_sprites.clear()


async def update_sprites():
    """Update all sprites in the game loop."""
    sprites = globals_list.sprites_group.sprites()
    _sync_moving_sprites(sprites)
    for sprite in sprites:
        sprite.events.is_clicked = False

        # Videos keep playing (and keep their sound in step) even while hidden,
        # so they are ticked before the is_hidden check below.
        sprite._tick()

        await run_sprite_callbacks(sprite)
        if sprite.is_hidden:
            continue

        if sprite._handle_frame_events():
            continue
        handle_sprite_click(sprite)
        handle_sprite_click_released(sprite)

    if mouse_state.click_release_happened:
        clear_click_tracking()

    globals_list.sprites_group.update()
    globals_list.sprites_group.draw(globals_list.display)
