"""Auto-start logic for running the game loop when the user forgets start_program()."""

import dis as _dis
import sys as _sys

from play.callback import callback_manager
from play.globals import globals_list, ProgramState
from play.utils import run_once as _run_once

_PAUSE_OPCODES = ("YIELD_VALUE", "RESUME")


def _opcode(frame):
    """Return the name of the instruction a frame stopped at."""
    return _dis.opname[frame.f_code.co_code[frame.f_lasti]]


def _start_after_the_script():
    """Start the program the script left unstarted, as play.start_program() at its end would."""
    if (
        globals_list.should_auto_start
        and globals_list.program_state is ProgramState.NOT_STARTED
    ):
        globals_list.started_by_auto_start = True
        globals_list.start_program_fn()


def _make_main_return_trace(existing_trace, existing_f_trace, existing_f_trace_lines):
    """Create the trace for the script's frame: it starts the program once the script ends normally."""

    def _on_main_return(frame, event, arg):
        if event == "return":
            instruction = _opcode(frame)
            if instruction not in _PAUSE_OPCODES:
                if instruction.startswith("RETURN"):
                    _start_after_the_script()
                if existing_trace is None:
                    _sys.settrace(None)
        # Return value of existing_f_trace is intentionally discarded: we
        # always keep _on_main_return as the local trace so we can detect
        # the 'return' event.  In practice, coverage tools (e.g. pytest-cov)
        # return themselves, so they are not disrupted.
        if existing_f_trace is not None:
            existing_f_trace(frame, event, arg)
        return _on_main_return

    _on_main_return.replaced = (existing_f_trace, existing_f_trace_lines)
    return _on_main_return


def _main_module_frame():
    """The frame running the student's script, or None."""
    # CPython-specific: _getframe() is an implementation detail but fine here
    # since pygame targets CPython.
    frame = _sys._getframe()
    while frame is not None:
        if (
            frame.f_globals.get("__name__") == "__main__"
            and frame.f_code.co_name == "<module>"
        ):
            return frame
        frame = frame.f_back
    return None


def _placeholder_trace(*_args):
    """Keep tracing on, so the trace on the script's frame sees it end."""


def stop_waiting_for_the_script():
    """Turn tracing off again when only auto-start had turned it on."""
    if _sys.gettrace() is _placeholder_trace:
        _sys.settrace(None)


@_run_once
def _schedule_auto_start():
    """Set up auto-start when the user's script finishes.

    Walks the call stack to find the __main__ frame and installs a trace
    that fires start_program() when that frame returns. This runs on the
    main thread before the interpreter shutdown — required for pygame on Windows.

    Preserves any existing sys.settrace (debuggers, coverage, etc.) by
    wrapping the frame trace instead of replacing the global trace.
    """
    globals_list.should_auto_start = True

    frame = _main_module_frame()
    if frame is not None:
        existing_trace = _sys.gettrace()
        if existing_trace is None:
            _sys.settrace(_placeholder_trace)
        frame.f_trace = _make_main_return_trace(
            existing_trace, frame.f_trace, frame.f_trace_lines
        )
        frame.f_trace_lines = False
    # If no __main__ frame was found (e.g. interactive REPL, embedded context),
    # should_auto_start is True but no trace is installed — start_program()
    # won't fire automatically and the user must call it explicitly.


callback_manager.on_first_callback = _schedule_auto_start


def _cleanup_auto_start():
    """Reset all auto-start state and give the script's frame back the trace auto-start replaced.

    Used by play.reset_program() to prevent state leakage between programs.
    """
    globals_list.program_state = ProgramState.NOT_STARTED
    globals_list.should_auto_start = False
    globals_list.started_by_auto_start = False
    _schedule_auto_start.has_run = False
    callback_manager.on_first_callback = _schedule_auto_start

    frame = _main_module_frame()
    if frame is not None and hasattr(frame.f_trace, "replaced"):
        frame.f_trace, frame.f_trace_lines = frame.f_trace.replaced
