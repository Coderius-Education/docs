"""Global variables for the game"""

import os as _os
from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Optional

import pygame

if TYPE_CHECKING:
    from play.objects.widgets.text_input import TextInput


class ProgramState(Enum):
    """Where the program is in its lifecycle."""

    NOT_STARTED = "not_started"
    RUNNING = "running"
    STOPPED = "stopped"


@dataclass
class Globals:
    sprites_group: pygame.sprite.LayeredUpdates = field(
        default_factory=pygame.sprite.LayeredUpdates
    )

    walls: list = field(default_factory=list)

    backdrop_type: str = "color"  # color or image
    backdrop: tuple = (255, 255, 255)

    frame_rate: int = 60
    width: int = 800
    height: int = 600

    gravity: object = None
    num_sim_steps: int = 10

    display: object = None  # This will be set in the screen module
    controllers: list = field(default_factory=list)

    program_state: ProgramState = ProgramState.NOT_STARTED
    error_shown: bool = False
    should_auto_start: bool = False
    started_by_auto_start: bool = False
    initial_pid: int = field(default_factory=_os.getpid)
    start_program_fn: object = None  # set by play.api.utils to avoid cyclic import
    focused_text_input: Optional["TextInput"] = None

    def reset(self):
        """Reset mutable game state to defaults.

        Note: ``gravity`` and ``display`` are intentionally NOT reset here.
        ``gravity`` requires re-initialisation with a pymunk Space object and
        is handled separately by play.physics._reset_physics().  ``display`` needs an
        active pygame Surface and is managed by the screen module.
        """
        self.sprites_group.empty()
        self.walls.clear()
        self.controllers.clear()
        self.backdrop_type = "color"
        self.backdrop = (255, 255, 255)
        self.frame_rate = 60
        self.width = 800
        self.height = 600
        self.num_sim_steps = 10
        self.program_state = ProgramState.NOT_STARTED
        self.error_shown = False
        self.should_auto_start = False
        self.started_by_auto_start = False
        self.focused_text_input = None

    def claim_first_error(self):
        """Mark that an error is shown; return True only for the program's first."""
        first = not self.error_shown
        self.error_shown = True
        return first


globals_list = Globals()
