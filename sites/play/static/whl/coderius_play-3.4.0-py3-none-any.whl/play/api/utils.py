"""Game functions and utilities."""

import asyncio as _asyncio
import logging as _logging
import os as _os

import pygame

from ..callback import callback_manager, CallbackType
from ..core import game_loop as _game_loop
from ..globals import globals_list, ProgramState
from ..io.keypress import keyboard_state
from ..loop import get_loop as _get_loop
from ..physics import set_physics_simulation_steps as _set_physics_simulation_steps
from ..objects.video import close_all_videos as _close_all_videos
from ..utils import color_name_to_rgb as _color_name_to_rgb


def start_program():
    """
    Calling this function starts your program running.

    play.start_program() should almost certainly go at the very end of your program.
    """
    if globals_list.program_state is not ProgramState.NOT_STARTED:
        raise RuntimeError(
            "You've already started the program! Calling play.start_program() "
            "twice can cause errors. Check to make sure it's only called once "
            "at the very bottom of your file."
        )

    globals_list.program_state = ProgramState.RUNNING
    globals_list.should_auto_start = False

    async def _run_start_then_loop():
        # The yield lets each callback set up before the first frame renders.
        callback_manager.run_callbacks(CallbackType.WHEN_PROGRAM_START)
        await _asyncio.sleep(0)
        _get_loop().create_task(_game_loop())

    try:
        try:
            _get_loop().run_until_complete(_run_start_then_loop())
        except RuntimeError:
            # loop.stop() raced with startup: fine if the program asked to stop.
            if globals_list.program_state is not ProgramState.STOPPED:
                raise
        # run_until_complete absorbs a stop_program() from the first frame, so
        # without this check the program would run on after asking to stop.
        if globals_list.program_state is not ProgramState.STOPPED:
            _get_loop().run_forever()
    finally:
        logger = _logging.getLogger("asyncio")
        logger.setLevel(_logging.CRITICAL)
        _close_all_videos()
        if _os.getpid() == globals_list.initial_pid:
            pygame.quit()


def stop_program():
    """
    Calling this function stops your program running.

    play.stop_program() should almost certainly go at the very end of your program.
    """
    globals_list.program_state = ProgramState.STOPPED
    _get_loop().stop()


async def animate():
    """
    Wait for the next frame to be drawn.
    """
    await _asyncio.sleep(0)


def set_backdrop(color):
    """Set the backdrop color or image for the game.
    :param color: The color or image to set as the backdrop.
    """
    globals_list.backdrop = _color_name_to_rgb(color)
    globals_list.backdrop_type = "color"


def set_backdrop_image(image):
    """Set the backdrop image for the game.
    :param image: The image to set as the backdrop.
    """
    globals_list.backdrop = pygame.image.load(image)
    globals_list.backdrop_type = "image"


async def timer(seconds=1.0):
    """Wait a number of seconds. Used with the await keyword like this:
    :param seconds: The number of seconds to wait.
    :return: True after the number of seconds has passed.
    """
    await _asyncio.sleep(seconds)
    return True


def key_is_pressed(*keys):
    """
    Returns True if any of the given keys are pressed.

    Example:

        @play.repeat_forever
        async def do():
            if play.key_is_pressed('up', 'w'):
                print('up or w pressed')
    """
    for key in keys:
        if key in keyboard_state.pressed:
            return True
    return False


def set_physics_simulation_steps(num_steps: int) -> None:
    """
    Set the number of simulation steps for the physics engine.
    :param num_steps: The number of simulation steps.
    """
    _set_physics_simulation_steps(num_steps)


# Register start_program on globals_list so auto_start.py can call it without
# importing this module (which would create a cyclic import via play.core).
globals_list.start_program_fn = start_program
