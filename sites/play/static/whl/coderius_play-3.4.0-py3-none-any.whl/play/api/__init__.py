"""
This module contains the API for the game.
"""

from .generators import (
    new_text,
    new_box,
    new_button,
    new_checkbox,
    new_circle,
    new_dropdown,
    new_image,
    new_progress_bar,
    new_radio_button,
    new_radio_group,
    new_slider,
    new_sound,
    new_video,
    new_database,
    new_text_input,
    new_tooltip,
)
from .events import (
    when_program_starts,
    repeat_forever,
    when_sprite_clicked,
    when_sprite_click_released,
    when_any_key_pressed,
    when_key_pressed,
    when_any_key_released,
    when_key_released,
    while_any_key_pressed,
    while_key_pressed,
    while_mouse_pressed,
    when_mouse_clicked,
    when_click_released,
    when_video_ends,
    when_video_starts,
    when_video_plays,
    when_video_pauses,
    when_video_frame_changes,
)
from .utils import (
    start_program,
    stop_program,
    animate,
    set_backdrop,
    set_backdrop_image,
    timer,
    key_is_pressed,
    set_physics_simulation_steps,
)
from . import auto_start as _auto_start  # noqa: F401 — trigger callback wiring
from .random import random_number, random_color, random_position
from ..callback.collision_callbacks import WallSide
