"""All the events that can be triggered in the game."""

import inspect

from ..callback import callback_manager, CallbackType
from ..callback.callback_helpers import run_async_callback, fire_async_callback
from ..io.keypress import (
    when_key as _when_key,
    when_any_key as _when_any_key,
    while_key as _while_key,
    while_any_key as _while_any_key,
)
from ..io.mouse import mouse
from ..utils.async_helpers import make_async


# @decorator
def when_program_starts(func):
    """
    Call code right when the program starts.

    Example:

        text = play.new_text(words='hi there!')

        @play.when_program_starts
        def show():
            text.words = 'started'

    :param func: The function to call when the program starts.
    :return: The decorator function.
    """
    async_callback = make_async(func)

    async def wrapper():
        return await run_async_callback(
            async_callback,
            [],
            [],
        )

    callback_manager.add_callback(CallbackType.WHEN_PROGRAM_START, wrapper)
    return func


# @decorator
def repeat_forever(func):
    """
    Calls the given function repeatedly in the game loop.

    Example:

        text = play.new_text(words='hi there!')

        @play.repeat_forever
        def turn():
            print("this is printing every single frame")


    :param func: The function to call repeatedly.
    :return: The decorator function.
    """
    if inspect.iscoroutinefunction(func):

        async def _run_and_unlock():
            try:
                await func()
            finally:
                repeat_wrapper.is_running = False

        async def repeat_wrapper():
            repeat_wrapper.is_running = True
            fire_async_callback(_run_and_unlock, [], [])

        repeat_wrapper.is_running = False
    else:
        # Sync callback — run inline so it sees the current frame's state.
        async_callback = make_async(func)

        async def repeat_wrapper():
            repeat_wrapper.is_running = True
            try:
                await run_async_callback(
                    async_callback,
                    [],
                    [],
                )
            finally:
                repeat_wrapper.is_running = False

        repeat_wrapper.is_running = False

    callback_manager.add_callback(CallbackType.REPEAT_FOREVER, repeat_wrapper)
    return func


# @decorator
def when_sprite_clicked(*sprites):
    """A decorator that runs a function when a sprite is clicked.

    Example:

        text = play.new_text(words='hi there!')

        @play.when_sprite_clicked(text)
        def show(sprite):
            text.words = 'clicked!'

    :param sprites: The sprites to run the function on.
    :return: The function to run.
    """

    def wrapper(func):
        for sprite in sprites:
            sprite.when_clicked(func, call_with_sprite=True)
        return func

    return wrapper


# @decorator
def when_sprite_click_released(*sprites):
    """A decorator that runs a function when a sprite click is released.

    Example:

        text = play.new_text(words='hi there!')

        @play.when_sprite_click_released(text)
        def show(sprite):
            text.words = 'released!'

    :param sprites: The sprites to run the function on.
    :return: The function to run.
    """

    def wrapper(func):
        for sprite in sprites:
            sprite.when_click_released(func, call_with_sprite=True)
        return func

    return wrapper


# @decorator
def when_any_key_pressed(func):
    """
    Calls the given function when any key is pressed.

    Example:

        text = play.new_text(words='hi there!')

        @play.when_any_key_pressed
        def show(key):
            text.words = key
    """
    if not callable(func):
        raise ValueError("""@play.when_any_key_pressed doesn't use a list of keys.""")
    return _when_any_key(func, released=False)


# @decorator
def when_key_pressed(*keys):
    """
    Calls the given function when any of the specified keys are pressed.

    Example:

        text = play.new_text(words='hi there!')

        @play.when_key_pressed('a')
        def show(key):
            text.words = key
    """
    return _when_key(*keys, released=False)


# @decorator
def when_any_key_released(func):
    """
    Calls the given function when any key is released.

    Example:

        text = play.new_text(words='hi there!')

        @play.when_any_key_released
        def show(key):
            text.words = key
    """
    if not callable(func):
        raise ValueError("""@play.when_any_key_released doesn't use a list of keys.""")
    return _when_any_key(func, released=True)


# @decorator
def when_key_released(*keys):
    """
    Calls the given function when any of the specified keys are released.

    Example:

        text = play.new_text(words='hi there!')

        @play.when_key_released('a')
        def show(key):
            text.words = key
    """
    return _when_key(*keys, released=True)


# @decorator
def while_any_key_pressed(func):
    """
    Calls the given function every frame while any key is held down.

    Example:

        text = play.new_text(words='hi there!')

        @play.while_any_key_pressed
        def show(key):
            text.words = key
    """
    if not callable(func):
        raise ValueError(
            "@play.while_any_key_pressed doesn't use a list of keys. "
            "To listen for specific keys, use @play.while_key_pressed('a') instead."
        )
    return _while_any_key(func)


# @decorator
def while_key_pressed(*keys):
    """
    Calls the given function every frame while any of the specified keys are held down.

    Example:

        text = play.new_text(words='hi there!')

        @play.while_key_pressed('left', 'right')
        def move(key):
            sprite.x += 5 if key == 'right' else -5
    """
    return _while_key(*keys)


# @decorator
def while_mouse_pressed(func):
    """
    Calls the given function every frame while the mouse button is held down.

    Example:
        text = play.new_text(words='hi there!')

        @play.while_mouse_pressed
        def show():
            text.words = 'mouse held'
    """
    return mouse.while_pressed(func)


# @decorator
def when_mouse_clicked(func):
    """
    Calls the given function when the mouse is clicked.

    Example:
        text = play.new_text(words='hi there!')

        @play.when_mouse_clicked
        def show():
            text.words = 'mouse click'
    """
    return mouse.when_clicked(func)


# @decorator
def when_click_released(func):
    """
    Calls the given function when the mouse click is released.

    Example:
        text = play.new_text(words='hi there!')

        @play.when_click_released
        def show():
            text.words = 'mouse click released'
    """
    return mouse.when_click_released(func)


def _video_event(method_name):
    """Build a module-level decorator that registers a video event."""

    def decorator_factory(*videos):
        def decorator(func):
            for video in videos:
                getattr(video, method_name)(func)
            return func

        return decorator

    return decorator_factory


# @decorator
def when_video_ends(*videos):
    """Run a function when any of the given videos reaches its end.

    Example:

        video = play.new_video('clip.mp4')

        @play.when_video_ends(video)
        def done():
            print('finished!')

    :param videos: The videos to watch.
    :return: The decorator function.
    """
    return _video_event("when_video_ends")(*videos)


# @decorator
def when_video_starts(*videos):
    """Run a function the first time any of the given videos starts playing.

    :param videos: The videos to watch.
    :return: The decorator function.
    """
    return _video_event("when_video_starts")(*videos)


# @decorator
def when_video_plays(*videos):
    """Run a function whenever any of the given videos starts or resumes.

    :param videos: The videos to watch.
    :return: The decorator function.
    """
    return _video_event("when_video_plays")(*videos)


# @decorator
def when_video_pauses(*videos):
    """Run a function whenever any of the given videos is paused.

    :param videos: The videos to watch.
    :return: The decorator function.
    """
    return _video_event("when_video_pauses")(*videos)


# @decorator
def when_video_frame_changes(*videos):
    """Run a function each time any of the given videos shows a new frame.

    The function may take a ``time`` parameter: how far into the video the new
    frame is, in seconds.

    :param videos: The videos to watch.
    :return: The decorator function.
    """
    return _video_event("when_video_frame_changes")(*videos)
