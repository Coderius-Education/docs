"""
This module contains helper functions for running callback functions.
"""

import inspect
import traceback

from ..io.logging import play_logger
from ..loop import get_loop as _get_loop


def run_callback(callback, required_args, optional_args, *args, **kwargs):
    """Schedule a callback as a fire-and-forget task.

    This is a convenience alias for :func:`fire_async_callback`.
    """
    fire_async_callback(callback, required_args, optional_args, *args, **kwargs)


def _resolve_callback_args(callback, required_args, optional_args, *args):
    """Resolve the arguments for a callback, respecting original_function wrappers.

    Returns the (actual_cb, callback_args) tuple, or raises ValueError if the
    callback signature doesn't match.
    """
    if not inspect.iscoroutinefunction(callback):
        raise ValueError("The callback function must be an async function.")
    actual_cb = callback
    if hasattr(callback, "original_function"):
        actual_cb = callback.original_function
    actual_args = inspect.getfullargspec(actual_cb).args
    if (
        len(required_args)
        <= len(actual_args)
        <= len(required_args) + len(optional_args)
    ):
        return actual_cb, args[: len(actual_args)]
    if len(required_args) == 0:
        raise ValueError(
            f"The callback function must not take in any arguments.\n"
            f"On line {actual_cb.__code__.co_firstlineno} in {actual_cb.__code__.co_filename}"
        )
    raise ValueError(
        f"The callback function must take in {len(required_args)} argument(s):\n"
        f"Required: {required_args}\n"
        f"{len(optional_args)} optional argument(s): {optional_args}\n"
        f"On line {actual_cb.__code__.co_firstlineno} in {actual_cb.__code__.co_filename}"
    )


async def run_async_callback(callback, required_args, optional_args, *args, **kwargs):
    """
    Run a callback function with the given arguments.
    :param callback: The callback function to run.
    :param required_args: The required arguments for the callback function.
    :param optional_args: The optional arguments for the callback function.
    :param args: The arguments to pass to the callback function.
    :param kwargs: The keyword arguments to pass to the callback
    :return: The result of the callback function.
    """
    _, callback_args = _resolve_callback_args(
        callback, required_args, optional_args, *args
    )
    await callback(*callback_args, **kwargs)


def _task_exception_handler(task):
    """Log and print exceptions from fire-and-forget callback tasks.

    Prints the full traceback to stderr so students see errors immediately,
    even if logging is not configured.
    """
    if task.cancelled():
        return
    exc = task.exception()
    if exc is not None:
        traceback.print_exception(type(exc), exc, exc.__traceback__)
        play_logger.critical("Error in callback task: %s", exc)


def fire_async_callback(callback, required_args, optional_args, *args, **kwargs):
    """Like run_async_callback but schedules the callback as a task (fire-and-forget).

    Use this for event callbacks (key press, mouse click, etc.) that should not
    block the game loop when they contain awaits like play.timer().
    """
    _, callback_args = _resolve_callback_args(
        callback, required_args, optional_args, *args
    )
    task = _get_loop().create_task(callback(*callback_args, **kwargs))
    task.add_done_callback(_task_exception_handler)


async def run_any_async_callback(callbacks, *args, **kwargs):
    """
    Run a callback function with the given arguments.
    :param callbacks: A list of callback functions to run.
    :param args: The arguments to pass to the callback function.
    :param kwargs: The keyword arguments to pass to the callback
    :return: The result of the callback function.
    """
    if not isinstance(callbacks, list):
        raise ValueError("The callbacks parameter must be a list of async functions.")

    for callback in callbacks:
        if callable(callback):
            await run_async_callback(callback, [], [], *args, **kwargs)
