"""This module contains the Image class, which is a subclass of the Sprite class."""

import math as _math
import os
import pygame

from .sprite import Sprite
from ..io.screen import convert_pos


class Image(Sprite):
    def __init__(self, image, x=0, y=0, angle=0, size=100, transparency=100):
        if isinstance(image, str):
            if not os.path.isfile(image):
                raise FileNotFoundError(f"Image file '{image}' not found.")
            self._image_filename = image
            # Keep the original, loaded image safe from modifications.
            self._source_image = pygame.image.load(image)
        else:
            self._image_filename = None
            self._source_image = image

        self._original_width = self._source_image.get_width()
        self._original_height = self._source_image.get_height()
        self._x = x
        self._y = y
        self._angle = angle
        self._size = size
        self._transparency = transparency
        self.rect = self._source_image.get_rect()

        # Initialize the parent sprite with this image, which starts physics using rect
        super().__init__(image=self._source_image)
        self.update()

    def update(self):
        """Update the image's position, size, angle, and transparency."""
        if self._should_recompute:
            # Generate the display image from the original source
            draw_image = pygame.transform.scale(
                self._source_image,
                (
                    max(round(self._original_width * self._size / 100), 1),
                    max(round(self._original_height * self._size / 100), 1),
                ),
            )
            angle_deg = _math.degrees(self.physics._pymunk_body.angle)
            draw_image = pygame.transform.rotate(draw_image, angle_deg)
            draw_image.set_alpha(round(self._transparency * 255 / 100))

            # Set the generated image as the sprite's current image
            self.image = draw_image
            self.rect = draw_image.get_rect()
            pos = convert_pos(self.x, self.y)
            self.rect.center = pos

        # Allow the parent class to handle hiding, collisions, etc.
        super().update()

    # The custom image property is removed to use the parent Sprite's property.
    # This ensures that the image managed by the Pygame sprite group is the
    # one generated in the update method.

    @property
    def image_filename(self):
        """Return the image filename."""
        return self._image_filename

    @image_filename.setter
    def image_filename(self, image: str):
        """Set the image from a file."""
        if not os.path.isfile(image):
            raise FileNotFoundError(f"Image file '{image}' not found.")
        self._image_filename = image
        self._source_image = pygame.image.load(image)
        self._original_width = self._source_image.get_width()
        self._original_height = self._source_image.get_height()
        self._should_recompute = True
        self.update()
